package com.ds.move02.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="category_master")
public class Category implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "category_code", nullable = false)
	private String categoryCode;
	
	@Column(name = "category_name", nullable = false)
	private String categoryName;
	
	// Self Reference Relatopn (upper category, subCategories)
	@ManyToOne(cascade={CascadeType.DETACH})
	@JoinColumn(name="upper_category_code")
	private Category upperCategory;

	@OneToMany(mappedBy="upperCategory")
	private Set<Category> subCateogories = new HashSet<Category>();

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "category_place", joinColumns = @JoinColumn(name = "category_code"), inverseJoinColumns = @JoinColumn(name = "place_id"))
	private Set<Place> places = new HashSet<Place>();
	
	@Column(name="category_level", nullable=false)
	private int categoryLevel;
	
	@Column(name="order_numeric", nullable=false)
	private int orderNumeric;
	
	@Column(name="nice_category1_code", nullable=true)
	private String niceCategory1Code;
	
	@Column(name="nice_category1_name", nullable=true)
	private String niceCategory1Name;

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Category getUpperCategory() {
		return upperCategory;
	}

	public void setUpperCategory(Category upperCategory) {
		this.upperCategory = upperCategory;
	}

	public Set<Category> getSubCateogories() {
		return subCateogories;
	}

	public void setSubCateogories(Set<Category> subCateogories) {
		this.subCateogories = subCateogories;
	}

	public Set<Place> getPlaces() {
		return places;
	}

	public void setPlaces(Set<Place> places) {
		this.places = places;
	}

	public int getCategoryLevel() {
		return categoryLevel;
	}

	public void setCategoryLevel(int categoryLevel) {
		this.categoryLevel = categoryLevel;
	}

	public int getOrderNumeric() {
		return orderNumeric;
	}

	public void setOrderNumeric(int orderNumeric) {
		this.orderNumeric = orderNumeric;
	}

	public String getNiceCategory1Code() {
		return niceCategory1Code;
	}

	public void setNiceCategory1(String niceCategory1Code) {
		this.niceCategory1Code = niceCategory1Code;
	}

	public String getNiceCategory1Name() {
		return niceCategory1Name;
	}

	public void setNiceCategory1Name(String niceCategory1Name) {
		this.niceCategory1Name = niceCategory1Name;
	}
	
	
	
}
