package com.ds.move02.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ds.move02.model.Place;

public interface PlaceRepository extends JpaRepository<Place, Integer>{

}
