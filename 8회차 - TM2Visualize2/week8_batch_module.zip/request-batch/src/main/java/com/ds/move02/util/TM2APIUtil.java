package com.ds.move02.util;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class TM2APIUtil {
	// 연관어 감성 추이 기본 url
	private static final String baseUrl = "http://qt.some.co.kr/TrendMap/JSON/ServiceHandler?command=GetAssociationTransitionBySentiment";
	
	// 언어
	private String lang = "ko";
	
	// 매체(channel)
	private String source;
	
	// 작성일
	private LocalDate startDate;
	private LocalDate endDate;
	
	// 주제어
	private String keyword;
	
	// 출력 주기
	private int period;
	
	// 분류체계 명
	private String categorySetName = "SM";
	
	// 출력 옵션
	private String[] outputOption;
	
	// 출력 연관어 개수
	private int topN = 30;
	
	// 연관어의 최소, 최대 빈도수
	private int cutOffFrequencyMin = 1;
	private int cutOffFrequencyMax;
	
	// 분류체계에 포함된 연관어만 출력
	private String[] categoryList;
	
	// categoryList 적용 시 "포함" / "제거" 여부
	private boolean categoryExclusive = false;
	
	// 연관어 지정 목록
	private String association;
	
	// 연관어 포함 prefix
	private String[] prefixIncList;
	
	// 연관어 제외 prefix
	private String[] prefixExcList;
	
	// prefix 설정 시 virtualtag 여부 설정
	private boolean prefixAllowVirtual = false;
	
	// 문서 필터에 사용할 키워드 지정
	// ex. :["+세종||세종시||세종특별자치시","-이것||저것"]
	private String keywordFilterList;
	
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public String getCategorySetName() {
		return categorySetName;
	}
	public void setCategorySetName(String categorySetName) {
		this.categorySetName = categorySetName;
	}
	public String[] getOutputOption() {
		return outputOption;
	}
	public void setOutputOption(String[] outputOption) {
		this.outputOption = outputOption;
	}
	public int getTopN() {
		return topN;
	}
	public void setTopN(int topN) {
		this.topN = topN;
	}
	public int getCutOffFrequencyMin() {
		return cutOffFrequencyMin;
	}
	public void setCutOffFrequencyMin(int cutOffFrequencyMin) {
		this.cutOffFrequencyMin = cutOffFrequencyMin;
	}
	public int getCutOffFrequencyMax() {
		return cutOffFrequencyMax;
	}
	public void setCutOffFrequencyMax(int cutOffFrequencyMax) {
		this.cutOffFrequencyMax = cutOffFrequencyMax;
	}
	public String[] getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(String[] categoryList) {
		this.categoryList = categoryList;
	}
	public boolean isCategoryExclusive() {
		return categoryExclusive;
	}
	public void setCategoryExclusive(boolean categoryExclusive) {
		this.categoryExclusive = categoryExclusive;
	}
	public String getAssociation() {
		return association;
	}
	public void setAssociation(String association) {
		this.association = association;
	}
	public String[] getPrefixIncList() {
		return prefixIncList;
	}
	public void setPrefixIncList(String[] prefixIncList) {
		this.prefixIncList = prefixIncList;
	}
	public String[] getPrefixExcList() {
		return prefixExcList;
	}
	public void setPrefixExcList(String[] prefixExcList) {
		this.prefixExcList = prefixExcList;
	}
	public boolean isPrefixAllowVirtual() {
		return prefixAllowVirtual;
	}
	public void setPrefixAllowVirtual(boolean prefixAllowVirtual) {
		this.prefixAllowVirtual = prefixAllowVirtual;
	}
	public String getKeywordFilterList() {
		return keywordFilterList;
	}
	public void setKeywordFilterList(String keywordFilterList) {
		this.keywordFilterList = keywordFilterList;
	}
	
	public void bindValues(Map<String, String> queryMap) {
		Field field = null;
		for(String key : queryMap.keySet()) {
			try {
				field = this.getClass().getDeclaredField(key);
				field.setAccessible(true);
				if(field.getType() == String.class)
					field.set(this, queryMap.get(key));
				else if(field.getType() == LocalDate.class)
					field.set(this, LocalDate.parse(queryMap.get(key)));
				else if(field.getType() == Boolean.class)
					field.set(this, Boolean.parseBoolean(queryMap.get(key)));
				else if(field.getType() == Integer.class)
					field.set(this, Integer.parseInt(queryMap.get(key)));
				else if(field.getType() == Double.class)
					field.set(this, Double.parseDouble(queryMap.get(key)));
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
				System.err.println(key + "is not valid key");
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
				System.err.println(queryMap.get(key) + "is not valid for key {" + key + "}");
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}
	
	// url builder
	public String buildUrl() {
		String urlString = this.baseUrl;
		
		// querymap 을 돌면서 일치하는 필드에 value 넣기.		
		Field[] fields = this.getClass().getDeclaredFields();
		for(Field f : fields) {
			try {
				Object val = null;
				if((val = f.get(this)) != null) {
					String kv = new String();
					if(f.getName() != "baseUrl")
						if(f.getType() == LocalDate.class) {
							LocalDate temp = (LocalDate) val;
							String tempVal = temp.format(DateTimeFormatter.BASIC_ISO_DATE);
							
							kv = "&" + f.getName() + "=" + tempVal;
						} else
							kv = "&" + f.getName() + "=" + val;
					urlString += kv;
				}
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}		
		return urlString;
	}
	
}

enum PeriodType {
	DAILY,
	WEEKLY,
	MONTHLY,
	QUARTERLY,
	HALFLY,
	YEARLY
}