package com.ds.move02.repositories;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ds.move02.model.KeywordMaster;

@Repository
public class KeywordMasterRepository {
    @Autowired
    private EntityManager entityManager;

    private Session getSession() {
        return entityManager.unwrap(Session.class);
    }
	
	public List<KeywordMaster> findAll(){
		Session session = getSession();
		List<KeywordMaster> result = null;
		
		String hql = "from KeywordMaster where placeId >= 2564";

		Query query = session.createQuery(hql);
		result = query.getResultList();
		
		return result;
	}
}
