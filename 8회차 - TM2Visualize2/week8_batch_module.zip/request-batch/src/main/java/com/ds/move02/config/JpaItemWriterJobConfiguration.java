package com.ds.move02.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.batch.item.database.builder.JpaPagingItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ds.move02.model.KeywordMaster;

@Configuration
public class JpaItemWriterJobConfiguration {
	@Autowired
    private JobBuilderFactory jobBuilderFactory;
	@Autowired
    private StepBuilderFactory stepBuilderFactory;
	@Autowired
    private EntityManagerFactory entityManagerFactory;
	@Autowired
	private MyItemWriter itemWriter;
	
    private static final int chunkSize = 10;

    @Bean
    public Job jpaItemWriterJob() {
    	System.out.println("This is writer job");
        return jobBuilderFactory.get("jpaItemWriterJob")
                .start(jpaItemWriterStep())
                .build();
    }

    @Bean
    public Step jpaItemWriterStep() {
    	System.out.println("This is writer step");
        return stepBuilderFactory.get("jpaItemWriterStep")
                .<KeywordMaster, KeywordMaster>chunk(chunkSize)
                .reader(jpaItemWriterReader())
//                .processor(jpaItemProcessor())
                .writer(itemWriter)
                .build();
    }

    @Bean
    public JpaPagingItemReader<KeywordMaster> jpaItemWriterReader() {
    	System.out.println("This is writer reader");
        return new JpaPagingItemReaderBuilder<KeywordMaster>()
                .name("jpaItemWriterReader")
                .entityManagerFactory(entityManagerFactory)
                .pageSize(chunkSize)
                .queryString("from KeywordMaster")
                .build();
    }

    @Bean
    public ItemProcessor<KeywordMaster, KeywordMaster> jpaItemProcessor() {
        return keywordMaster -> new KeywordMaster();
    }


//    @Bean
//    public JpaItemWriter<SentimentAnalysis> jpaItemWriter() {
//        JpaItemWriter<SentimentAnalysis> jpaItemWriter = new JpaItemWriter<>();
//        jpaItemWriter.setEntityManagerFactory(entityManagerFactory);
//        return jpaItemWriter;
//    }
}