package com.ds.move02.config;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ds.move02.model.KeywordMaster;
import com.ds.move02.service.SentimentAnalysisService;

@Component
public class MyItemWriter implements ItemWriter<KeywordMaster> {

    @Autowired
    private SentimentAnalysisService saService;

    @Override
    public void write(List<? extends KeywordMaster> keywords) throws Exception {
    	System.out.println("My Item Writer init");
    	for(KeywordMaster kw : keywords) {
    		System.out.println(kw);
    	}
    	saService.createDailyAnalysis(keywords);
    }
}