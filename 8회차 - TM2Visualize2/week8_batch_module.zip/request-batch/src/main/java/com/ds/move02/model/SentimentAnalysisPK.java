package com.ds.move02.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class SentimentAnalysisPK implements Serializable{
	private static final long serialVersionUID = 1L;
	
    protected char snsType;
    protected String registerDate;
    protected int placeId;

    public SentimentAnalysisPK() {}

    public SentimentAnalysisPK(char snsType, String registerDate, int placeId) {
        this.snsType = snsType;
        this.registerDate = registerDate;
        this.placeId = placeId;
    }

	public char getchar() {
		return snsType;
	}

	public void setchar(char snsType) {
		this.snsType = snsType;
	}

	public String getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}
	
    

}
