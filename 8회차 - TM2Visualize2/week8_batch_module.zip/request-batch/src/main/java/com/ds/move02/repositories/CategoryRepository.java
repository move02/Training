package com.ds.move02.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ds.move02.model.Category;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long>{
    public List<Category> findByCategoryCodeStartingWithOrderByCategoryCode(String categoryCode);
    public List<Category> findByCategoryNameLikeOrderByCategoryCode(String categoryName);
    public List<Category> findByNiceCategory1CodeLikeOrderByCategoryCode(String niceCategory1Code);
    public List<Category> findByNiceCategory1NameLikeOrderByCategoryCode(String niceCategory1Name);
    
}
