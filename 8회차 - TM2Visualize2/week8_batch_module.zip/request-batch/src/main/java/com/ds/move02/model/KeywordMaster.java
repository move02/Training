package com.ds.move02.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

@Entity
@IdClass(KeywordMasterPK.class)
@Table(name = "tb_sangga_keyword_master")
public class KeywordMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="sns_type")
	private char snsType;

	@Id
	@Column(name="placeId")
	private int placeId;

	@MapsId("placeId")
	@ManyToOne(optional = false)
	@JoinColumns(value = { @JoinColumn(name = "keyword_id", referencedColumnName = "id"),
			@JoinColumn(name = "keyword", referencedColumnName = "place_name") })
	private Place place;
	
	@Column(name="include")
	private String include;
	
	@Column(name="exclude")
	private String exclude;
	
	public char getSnsType() {
		return snsType;
	}

	public void setSnsType(char snsType) {
		this.snsType = snsType;
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	public Place getPlace() {
		return place;
	}

	public void setPlace(Place place) {
		this.place = place;
	}

	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}

	public String getExclude() {
		return exclude;
	}

	public void setExclude(String exclude) {
		this.exclude = exclude;
	}

	@Override
	public String toString() {
		return "KeywordMaster [snsType=" + snsType + ", placeId=" + placeId + ", place=" + place + ", include="
				+ include + ", exclude=" + exclude + "]";
	}
	
}
