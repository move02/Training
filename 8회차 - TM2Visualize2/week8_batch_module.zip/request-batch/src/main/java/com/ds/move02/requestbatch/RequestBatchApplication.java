package com.ds.move02.requestbatch;

import javax.transaction.Transactional;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.EventListener;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ds.move02.model.Place;
import com.ds.move02.model.SentimentAnalysis;
import com.ds.move02.repositories.SentimentAnalysisRepository;
import com.ds.move02.service.PlaceService;

@SpringBootApplication(scanBasePackages = "com.ds.move02")
@EnableBatchProcessing
@ComponentScan(basePackages = "com.ds.move02")
@EntityScan(basePackages = "com.ds.move02.model")
@EnableJpaRepositories(basePackages = "com.ds.move02.repositories")
@EnableTransactionManagement
@EnableScheduling
@EnableAsync
public class RequestBatchApplication {
	@Autowired
	SentimentAnalysisRepository saRepos;
	@Autowired
	PlaceService placeService;
	
	public static void main(String[] args) {
		SpringApplication.run(RequestBatchApplication.class, args);
	}
	
//	@EventListener(ApplicationReadyEvent.class)
//	@Transactional
//	public void doSomethingAfterStartup() {
//		SentimentAnalysis sa = new SentimentAnalysis();
//
//		Place place = placeService.getPlace(1);
//		System.out.println(place.getPlaceName());
//		
//		sa.setPlace(place);
//		sa.setPlaceId(place.getId());
//		sa.setSnsType('B');
//		sa.setRegisterDate("20191101");
//		sa.setPositive_count(11);
//		sa.setNeutral_count(1);
//		sa.setNegative_count(3);
//		sa.calcEmotionalScore();
//		
//		saRepos.save(sa);
//	}
}