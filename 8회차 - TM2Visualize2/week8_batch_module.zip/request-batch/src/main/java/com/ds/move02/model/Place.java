package com.ds.move02.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tb_place")
public class Place implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id", nullable=false)
	private int id;

	@Column(name="place_name", nullable=false)
	private String placeName;
	
	@Column(name="name_alias", nullable=false)
	private String nameAlias;
	
	@ManyToMany(mappedBy="places")
	private Set<Category> categories = new HashSet<Category>();

	@OneToMany(mappedBy="place")
	private Set<KeywordMaster> keywordMasters = new HashSet<KeywordMaster>();
	
	@OneToMany(mappedBy="place")
	private Set<SentimentAnalysis> sentimentAnalysis = new HashSet<SentimentAnalysis>();
	
	@Column(name="address_refined", nullable=false)
	private String addressRefined;
	
	@Column(name="hd_emd_name", nullable=false)
	private String hdEmdName;
	
	@Column(name="hd_emd_code", nullable=false)
	private int hdEmdCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlaceName() {
		return placeName;
	}

	public void setPlaceName(String placeName) {
		this.placeName = placeName;
	}

	public String getNameAlias() {
		return nameAlias;
	}

	public void setNameAlias(String nameAlias) {
		this.nameAlias = nameAlias;
	}

	public Set<Category> getCategories() {
		return categories;
	}

	public void setCategories(Set<Category> categories) {
		this.categories = categories;
	}
	
	public Set<KeywordMaster> getKeywordMasters() {
		return keywordMasters;
	}

	public void setKeywordMasters(Set<KeywordMaster> keywordMasters) {
		this.keywordMasters = keywordMasters;
	}

	public Set<SentimentAnalysis> getSentimentAnalysis() {
		return sentimentAnalysis;
	}

	public void setSentimentAnalysis(Set<SentimentAnalysis> sentimentAnalysis) {
		this.sentimentAnalysis = sentimentAnalysis;
	}

	public String getAddressRefined() {
		return addressRefined;
	}

	public void setAddressRefined(String addressRefined) {
		this.addressRefined = addressRefined;
	}

	public String getHdEmdName() {
		return hdEmdName;
	}

	public void setHdEmdName(String hdEmdName) {
		this.hdEmdName = hdEmdName;
	}

	public int getHdEmdCode() {
		return hdEmdCode;
	}

	public void setHdEmdCode(int hdEmdCode) {
		this.hdEmdCode = hdEmdCode;
	}
	
	
}
