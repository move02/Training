package com.ds.move02.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

public class KeywordMasterPK implements Serializable{
	private static final long serialVersionUID = 1L;

    protected char snsType;
    protected int placeId;

    public KeywordMasterPK() {}

    public KeywordMasterPK(char snsType, int placeId) {
        this.snsType = snsType;
        this.placeId = placeId;
    }

	public char getchar() {
		return snsType;
	}

	public void setchar(char snsType) {
		this.snsType = snsType;
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}
	
    
}
