package com.ds.move02.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ds.move02.model.ScoreObject;
import com.ds.move02.model.SentimentAnalysis;

@Repository
public class SentimentAnalysisRepository {
    @Autowired
    private EntityManager entityManager;

    private Session getSession() {
        return entityManager.unwrap(Session.class);
    }
	
	
	public void save(SentimentAnalysis analysis) {
		Session session = getSession();
		session.saveOrUpdate(analysis);
	}
	
	public List<SentimentAnalysis> findAll(String startDate, String endDate) {
		List<SentimentAnalysis> result = null;
		Session session = getSession();

		try {
			String hql = "select sa from SentimentAnalysis sa "
					+ "where sa.registerDate between :startDate and :endDate "
					+ "order by sa.registerDate";

			Query query = session.createQuery(hql);
			query.setParameter("startDate", startDate);
			query.setParameter("endDate", endDate);

			result = query.getResultList();
		} catch (HibernateException e) {

			e.printStackTrace();
		}

		return result;
	}

	public List<SentimentAnalysis> findByCategoryId(int categoryId, String startDate, String endDate) {
		List<SentimentAnalysis> result = null;
		Session session = getSession();

		try {
			String hql = "select sa from SentimentAnalysis sa "
					+ "join sa.place.categories as ca on ca.id = :categoryId "
					+ "where sa.registerDate between :startDate and :endDate "
					+ "order by sa.registerDate";

			Query query = session.createQuery(hql);
			query.setParameter("categoryId", categoryId);
			query.setParameter("startDate", startDate);
			query.setParameter("endDate", endDate);

			result = query.getResultList();
		} catch (HibernateException e) {

			e.printStackTrace();
		}

		return result;
	}
	
	public List<ScoreObject> getChartData(char snsType, String category){
		List<ScoreObject> chartData = new ArrayList<ScoreObject>();
		Session session = getSession();
		
		String hql = "select avg(sa.positive_count) as positive, "
				+ "avg(sa.negative_count) as negative, avg(sa.neutral_count) as neutral, "
				+ "avg(sa.emotionalScore) as score, substring(sa.registerDate,1,6) "
				+ "from SentimentAnalysis sa ";
		if(!category.equals("A")) {
			hql += "join sa.place.categories ct where ct.niceCategory1Code = :category ";
			if(snsType != 'A') {
				hql += "and sa.snsType = :snsType ";
			}
		} else {
			if(snsType != 'A') {
				hql += "where sa.snsType = :snsType ";
			}
		}
		
		
		hql += "group by substring(sa.registerDate,1,6) ";
		
		
		hql += "order by sa.registerDate";

//		String hql = "select sa.snsType, avg(sa.positive_count) as positive, "
//				+ "avg(sa.negative_count) as negative, avg(sa.neutral_count) as neutral, "
//				+ "avg(sa.emotionalScore) as score, substring(sa.registerDate,1,6) "
//				+ "from SentimentAnalysis as sa "
//				+ "join sa.place.categories as ct ct.niceCategory1Code = :category "
//				+ "group by substring(sa.registerDate,1,6), sa.snsType "
//				+ "where sa.snsType = :snsType"
//				+ "order by sa.registerDate";

		Query query = session.createQuery(hql);
		
		if(!category.equals("A")) {
			query.setParameter("category", category);
		}
		
		if(snsType != 'A') {
			query.setParameter("snsType", snsType);
		}

       	List<Object[]> resultList = query.getResultList();
        
        if (!resultList.isEmpty()) {
            for (int i = 0; i < resultList.size(); i++) {
               ScoreObject sc = new ScoreObject();
               sc.setPositive((Double) resultList.get(i)[0]);
               sc.setNegative((Double) resultList.get(i)[1]);
               sc.setNeutral((Double) resultList.get(i)[2]);
               sc.setScore((Double) resultList.get(i)[3]);
               sc.setRegisterDate((String) resultList.get(i)[4]);
               chartData.add(sc);
            }
         }
		
		return chartData;
	}
	
	public List<ScoreObject> getChartData(char snsType, String category, String name){
		List<ScoreObject> chartData = new ArrayList<ScoreObject>();
		Session session = getSession();
		
		String hql = "select avg(sa.positive_count) as positive, "
				+ "avg(sa.negative_count) as negative, avg(sa.neutral_count) as neutral, "
				+ "avg(sa.emotionalScore) as score, substring(sa.registerDate,1,6) "
				+ "from SentimentAnalysis sa ";
		if(!category.equals("A")) {
			hql += "join sa.place.categories ct where ct.niceCategory1Code = :category ";
			hql += "and sa.place.placeName like :placeName ";
		}
		else
			hql += "where sa.place.placeName like :placeName ";

		
		if(snsType != 'A') {
			hql += "and sa.snsType = :snsType ";
		}
		
		
		hql += "group by substring(sa.registerDate,1,6) ";
		
		
		hql += "order by sa.registerDate";

		Query query = session.createQuery(hql);
		
		query.setParameter("placeName", name);
		
		if(!category.equals("A")) {
			query.setParameter("category", category);
		}
		
		if(snsType != 'A') {
			query.setParameter("snsType", snsType);
		}

       	List<Object[]> resultList = query.getResultList();
        
        if (!resultList.isEmpty()) {
            for (int i = 0; i < resultList.size(); i++) {
               ScoreObject sc = new ScoreObject();
               sc.setPositive((Double) resultList.get(i)[0]);
               sc.setNegative((Double) resultList.get(i)[1]);
               sc.setNeutral((Double) resultList.get(i)[2]);
               sc.setScore((Double) resultList.get(i)[3]);
               sc.setRegisterDate((String) resultList.get(i)[4]);
               chartData.add(sc);
            }
         } else {
        	 resultList = null;
         }
		
		return chartData;
	}
}
