package com.ds.move02.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.move02.model.Category;
import com.ds.move02.model.Place;
import com.ds.move02.repositories.CategoryRepository;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Service
public class CategoryService {
	@Autowired
	CategoryRepository categoryRepository;
	
	@Transactional
	public JsonArray getCategoryByCategoryCodeLike(String categoryCode){
		List<Category> categories = categoryRepository.findByCategoryCodeStartingWithOrderByCategoryCode(categoryCode);
		JsonArray result = new JsonArray();
		
		for(Category cat : categories) {
			JsonObject obj = new JsonObject();
			
			obj.addProperty("code", cat.getCategoryCode());
			obj.addProperty("name", cat.getCategoryName());
			obj.addProperty("lv", cat.getCategoryLevel());
			Hibernate.initialize(cat.getPlaces());
			
			JsonArray placeArr = new JsonArray();
			
			for(Place place : cat.getPlaces()) {
				JsonObject placeObj = new JsonObject();
				
				placeObj.addProperty("name", place.getPlaceName());
				placeObj.addProperty("dong", place.getHdEmdName());
				placeArr.add(placeObj);
			}
			
			obj.addProperty("places", placeArr.toString());
			result.add(obj);
		}
		
		return result;
	}
}
