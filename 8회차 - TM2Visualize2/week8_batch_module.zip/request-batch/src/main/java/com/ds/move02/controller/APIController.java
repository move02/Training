package com.ds.move02.controller;

import javax.annotation.PostConstruct;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ds.move02.service.SentimentAnalysisService;
import com.google.gson.JsonArray;

@RestController
@RequestMapping("/api")
public class APIController {
    @Autowired
    JobLauncher jobLauncher;
 
    @Autowired
    Job processJob;
    
    @Autowired
    SentimentAnalysisService saService;
    
    @PostConstruct
    public void initialize() {
    	System.out.println("api controller initialized");
    }
 
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    @Scheduled(cron = "${job.cron.rate.daily}")
    public String handle() throws Exception {
            JobParameters jobParameters = new JobParametersBuilder().addLong("time", System.currentTimeMillis())
                    .toJobParameters();
            jobLauncher.run(processJob, jobParameters);
 
        return "Batch job has been invoked";
    }
    
    @GetMapping(value="/scorechart")
    public String getChartData(@RequestParam(name="category", required=true, defaultValue="A") String category,
			@RequestParam(name="snsType", required=true, defaultValue="A") Character snsType,
			@RequestParam(name="name", required=false) String name) {
    	if(name == null)
    		return saService.getScoreChartData(snsType, category).toString();
    	else {
    		JsonArray result = saService.getScoreChartDataByName(snsType, category, name);
    		if(result == null) {
    			return "empty";
    		} 
    		else
    			return result.toString();
    	}
    }
}
