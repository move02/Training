package com.ds.move02.model;

public class ScoreObject {
	private double score;
	private double positive;
	private double negative;
	private double neutral;	
	private String registerDate;
	private char snsType;
	
	public char getSnsType() {
		return snsType;
	}
	public void setSnsType(char snsType) {
		this.snsType = snsType;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public double getPositive() {
		return positive;
	}
	public void setPositive(double positive) {
		this.positive = positive;
	}
	public double getNegative() {
		return negative;
	}
	public void setNegative(double negative) {
		this.negative = negative;
	}
	public double getNeutral() {
		return neutral;
	}
	public void setNeutral(double neutral) {
		this.neutral = neutral;
	}
	public String getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
	
	
}
