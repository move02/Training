package com.ds.move02.service;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ds.move02.model.KeywordMaster;
import com.ds.move02.model.ScoreObject;
import com.ds.move02.model.SentimentAnalysis;
import com.ds.move02.repositories.KeywordMasterRepository;
import com.ds.move02.repositories.SentimentAnalysisRepository;
import com.ds.move02.util.HttpConnectionConfig;
import com.ds.move02.util.RestTemplateUtil;
import com.ds.move02.util.TM2APIUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service
public class SentimentAnalysisService {
	@Autowired
	SentimentAnalysisRepository saRepository;
	@Autowired
	KeywordMasterRepository kmRepository;

	private final static String[] channels = {"twitter", "blog", "news", "insta"};
	
	@Transactional
	public void createMassAnalysis() {
		List<KeywordMaster> kmList = kmRepository.findAll();
		
		TM2APIUtil tm2Util = new TM2APIUtil();
		
		LocalDate start = LocalDate.of(2018,1,1);
		System.out.println("Mass Analysis started");
		int count = 0;
		for(KeywordMaster km : kmList) {
			System.out.println("Current " + (++count) + "개 째");
			if(km.getExclude().equals("all"))
				continue;
			for(int yy = start.getYear(); yy <= 2019; yy++) {
				for(int mm = 1; mm <= 12; mm++) {
					LocalDate thisMonth = LocalDate.of(yy,mm,1);
					
					Hibernate.initialize(km.getPlace());
					
					String kw = km.getPlace().getPlaceName();
					tm2Util.setKeyword(kw);
					tm2Util.setStartDate(thisMonth.withDayOfMonth(1));
					tm2Util.setEndDate(thisMonth.withDayOfMonth(thisMonth.lengthOfMonth()));
					tm2Util.setPeriod(0);
					
					String source = null;
					switch(km.getSnsType()) {
					case 'B':
						source = "blog";
						break;
					case 'N':
						source = "news";
						break;
					case 'T':
						source = "twitter";
						break;
					case 'I':
						source = "insta";
						break;
					default:
						break;
					}
					
					tm2Util.setSource(source);
					String url = tm2Util.buildUrl();
					requestAndSave(km, km.getSnsType(), url);
				
					
				}
			}
			
		}
	}
	
	@Transactional
	public void createDailyAnalysis(List<? extends KeywordMaster> keywords) {
		TM2APIUtil tm2Util = new TM2APIUtil();
		
		LocalDate today = LocalDate.now();
		for(KeywordMaster km : keywords) {
			Hibernate.initialize(km.getPlace());
			
			System.out.println(km);
			
			String kw = km.getPlace().getPlaceName();
			tm2Util.setKeyword(kw);
			tm2Util.setStartDate(today.minusDays(1));
			tm2Util.setEndDate(today);
			tm2Util.setPeriod(0);

			String source = null;
			switch(km.getSnsType()) {
			case 'B':
				source = "blog";
				break;
			case 'N':
				source = "news";
				break;
			case 'T':
				source = "twitter";
				break;
			case 'I':
				source = "insta";
				break;
			default:
				break;
			}
			
			tm2Util.setSource(source);
			String url = tm2Util.buildUrl();
			requestAndSave(km, km.getSnsType(), url);
			
		}
		
	}
	
	@Transactional
	public JsonArray getScoreChartData(char snsType, String category) {
		JsonArray chartData = new JsonArray();
		
		List<ScoreObject> dataObjs = saRepository.getChartData(snsType, category);
		for(ScoreObject sc : dataObjs) {
			JsonObject obj = new JsonObject();
			
			obj.addProperty("positive", sc.getPositive());
			obj.addProperty("negative", sc.getNegative());
			obj.addProperty("neutral", sc.getNeutral());
			obj.addProperty("score", sc.getScore());
			obj.addProperty("registerDate", sc.getRegisterDate());
			
			chartData.add(obj);
		}
		
		return chartData;
	}
	
	@Transactional
	public JsonArray getScoreChartDataByName(char snsType, String category, String name) {
		JsonArray chartData = new JsonArray();
		
		List<ScoreObject> dataObjs = saRepository.getChartData(snsType, category, name);
		if(dataObjs != null) {
			for(ScoreObject sc : dataObjs) {
				JsonObject obj = new JsonObject();
				
				obj.addProperty("positive", sc.getPositive());
				obj.addProperty("negative", sc.getNegative());
				obj.addProperty("neutral", sc.getNeutral());
				obj.addProperty("score", sc.getScore());
				obj.addProperty("registerDate", sc.getRegisterDate());
				
				chartData.add(obj);
			}
			
			return chartData;
		} else {
			return null;
		}
	}
	
	@Transactional
	@Async
	private void requestAndSave(KeywordMaster km, char snsType, String url) {
		String kw = km.getPlace().getPlaceName();
		HttpConnectionConfig config = new HttpConnectionConfig();
		
		RestTemplateUtil rtUtil = new RestTemplateUtil(config.getCustomRestTemplate());
		URI reqUrl = URI.create(url);
		
		if(km.getInclude() != null)
			url += "&keywordFilterList=+" + km.getInclude();
		if(km.getExclude() != null)
			url += "&keywordFilterList=-" + km.getExclude();
		
		ResponseEntity<String> responseEntity = rtUtil.getResponse(url);
//		System.out.println("url : " + url);
		if(responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.hasBody()) {
			JsonParser parser = new JsonParser();
			
			JsonElement whole = parser.parse(responseEntity.getBody());
			JsonObject wholeObj = whole.getAsJsonObject();
			
			JsonArray rows = wholeObj.get("rows").getAsJsonArray();
			
			for(JsonElement row : rows) {
				JsonObject rowObj = row.getAsJsonObject();
				String date = rowObj.get("date").getAsString();
				int positive = 0, negative = 0, neutral = 0;
				
				JsonObject kwObj = rowObj.get(kw).getAsJsonObject(); 
				
				positive = kwObj.get("positive").getAsInt();
				neutral = kwObj.get("neutral").getAsInt();
				negative = kwObj.get("negative").getAsInt();
				
				if(positive == 0 && neutral == 0 && negative == 0)
					continue;
				
				SentimentAnalysis analysis = new SentimentAnalysis();
				
				analysis.setPlace(km.getPlace());
				analysis.setPlaceId(km.getPlace().getId());
				analysis.setSnsType(snsType);
				analysis.setRegisterDate(date);
				analysis.setPositive_count(positive);
				analysis.setNeutral_count(neutral);
				analysis.setNegative_count(negative);
				analysis.calcEmotionalScore();
				
				saRepository.save(analysis);
				System.out.println("[" + date + "]Keyword : " + km.getPlace().getPlaceName() + " - " + snsType + " saved");
			}
		}
	}
}
