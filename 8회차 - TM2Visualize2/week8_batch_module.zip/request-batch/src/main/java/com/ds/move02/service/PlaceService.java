package com.ds.move02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.move02.model.Place;
import com.ds.move02.repositories.PlaceRepository;

@Service
public class PlaceService {
	@Autowired
	PlaceRepository pr;
	
	public Place getPlace(int id) {
		return pr.getOne(id);
	}
}
