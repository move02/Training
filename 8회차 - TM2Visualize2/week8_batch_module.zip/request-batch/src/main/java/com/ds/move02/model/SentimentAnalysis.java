package com.ds.move02.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

import org.hibernate.annotations.JoinColumnOrFormula;
import org.hibernate.annotations.JoinColumnsOrFormulas;
import org.hibernate.annotations.JoinFormula;

@Entity
@IdClass(SentimentAnalysisPK.class)
@Table(name="tb_sangga_sentiment_analysis")
public class SentimentAnalysis implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="sns_type")
    private char snsType;

	@Id
	@Column(name="register_date")
    private String registerDate;

	@Id
	@Column(name="place_id")
    private int placeId;

	@ManyToOne(optional = false)
	@JoinColumn(name="keyword_id",referencedColumnName="id")
	private Place place;
	
	@Column(name="positive_count")
	private int positive_count;

	@Column(name="negative_count")
	private int negative_count;

	@Column(name="neutral_count")
	private int neutral_count;

	@Column(name="emo_score")
	private int emotionalScore;
	
	public char getSnsType() {
		return snsType;
	}

	public void setSnsType(char snsType) {
		this.snsType = snsType;
	}

	public String getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public int getPlaceId() {
		return placeId;
	}

	public void setPlaceId(int placeId) {
		this.placeId = placeId;
	}

	public Place getPlace() {
		return place;
	}

	public void setPlace(Place place) {
		this.place = place;
	}

	public int getPositive_count() {
		return positive_count;
	}

	public void setPositive_count(int positive_count) {
		this.positive_count = positive_count;
	}

	public int getNegative_count() {
		return negative_count;
	}

	public void setNegative_count(int negative_count) {
		this.negative_count = negative_count;
	}

	public int getNeutral_count() {
		return neutral_count;
	}

	public void setNeutral_count(int neutral_count) {
		this.neutral_count = neutral_count;
	}

	public int getEmotionalScore() {
		return emotionalScore;
	}

	public void setEmotionalScore(int emotionalScore) {
		this.emotionalScore = emotionalScore;
	}
	
	public void calcEmotionalScore() {
		int bunmo = this.positive_count + this.neutral_count + this.negative_count;
		int bunja = this.positive_count - this.negative_count;
		
		int result = 0;
		if(bunmo == 0)
			result = 50;
		else
			result = (((bunja/bunmo) * 100) + 100)/2;
		
		this.setEmotionalScore(result);
	}

	@Override
	public String toString() {
		return "SentimentAnalysis [snsType=" + snsType + ", registerDate=" + registerDate + ", placeId=" + placeId
				+ ", place=" + place + ", positive_count=" + positive_count + ", negative_count=" + negative_count
				+ ", neutral_count=" + neutral_count + ", emotionalScore=" + emotionalScore + "]";
	}
	
	
	
}
