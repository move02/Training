package com.ds.move02.model;

public enum SnsType {
    BLOG('B'), NEWS('N'), TWITTER('T'), INSTAGRAM('I');
	
	private char type;
	
	SnsType(char type) {
		this.type = type;
	}
}
