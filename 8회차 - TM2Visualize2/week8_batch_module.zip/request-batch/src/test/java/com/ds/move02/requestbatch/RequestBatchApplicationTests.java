package com.ds.move02.requestbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
