package reader;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.univocity.parsers.tsv.TsvParser;
import com.univocity.parsers.tsv.TsvParserSettings;

public class TsvReader {
	// members
	private TsvParser parser;

	// constructor
	// TSV Reader 클래스 기본 설정
	public TsvReader() {
		TsvParserSettings settings = new TsvParserSettings();
		settings.getFormat().setLineSeparator("\n");
		this.parser = new TsvParser(settings);
	}

	// methods
	public List<String[]> readFile(String path) {
		List<String[]> allRows = null;

		try {
			allRows = parser.parseAll(getReader(path));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return allRows;
	}

	private Reader getReader(String path) {
		File file = new File(path);
		InputStream inputStream = null;
		Reader reader = null;
		
		try {
			inputStream = new BufferedInputStream(new FileInputStream(file));
			reader = new InputStreamReader(inputStream, "UTF-8");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		return reader;
	}

}
