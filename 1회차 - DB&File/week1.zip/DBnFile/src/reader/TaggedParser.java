package reader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import repos.Document;

public class TaggedParser {
	public List<Document> parseAll(Reader reader) throws IOException {
		List<Document> results = new ArrayList<>();
		
		BufferedReader br = new BufferedReader(reader);
		int character = 0;

		List<Character> charList = null;
		boolean hasStarted = false;

		while ((character = br.read()) != -1) {
			StringBuilder startEndQ = new StringBuilder();

			int newchar = 0;
			startEndQ.append((char) character);
			while (!startEndQ.toString().equals("^[START]\n")) {
				if (startEndQ.length() > 10 && !startEndQ.toString().equals("^[START]\n")) {
					System.out.println("DataFile is broken. System exit");
					System.exit(1);
				}
				startEndQ.append((char) br.read());
			}

			startEndQ = new StringBuilder();
			hasStarted = true;
			charList = new ArrayList<>();

			char endSignal = '\0';

			while (hasStarted && ((newchar = br.read()) != -1)) {
				if (newchar == -1) {
					System.out.println("Unexpected EOF. System exit");
					System.exit(0);
				}

				if (newchar == '^') {
					endSignal = (char) newchar;
				} else if (endSignal == '^' && newchar == '[') {
					startEndQ.append(endSignal);
					startEndQ.append((char)newchar);
					boolean isEnd = true;
					
					while (!startEndQ.toString().equals("^[END]\n")) {
						if (startEndQ.length() > 8 && !startEndQ.toString().equals("^[END]\n")) {
							for(int j = 0; j < startEndQ.length(); j++)
								charList.add(startEndQ.charAt(j));
							isEnd = false;
							break;
						}
						startEndQ.append((char) br.read());
					}
					
					if(isEnd) {
						charList.remove(charList.size()-1);
						hasStarted = false;
					}
				} else {
					endSignal = '\0';
				}

				if(hasStarted)
					charList.add((char) newchar);
			}

			Document doc = buildString(charList);
			results.add(doc);
		}

		return results;
	}

	public Document buildString(List<Character> charList) {
		StringBuilder builder = new StringBuilder();

		for (Character ch : charList) {
			builder.append(ch);
		}

		String docString = builder.toString();
		Document document = parseObject(docString);

		return document;
	}

	public Document parseObject(String docString) {
		Document document = new Document();
		
		Field[] fields = document.getClass().getDeclaredFields();
		
		StringTokenizer propertyTokenizer = new StringTokenizer(docString, "\n");
		
		boolean isKey = false, isConcat = false;
		String key = null, value = null;

		while (propertyTokenizer.hasMoreTokens()) {
			String singleLine = propertyTokenizer.nextToken();
			
			isKey = false;
			
			for(Field f : fields) {
				if(("["+f.getName()+"]").equals(singleLine)) {
					isKey = true;
					isConcat = false;
					break;
				}
			}
			
			if(isKey == false && value!= null)
				isConcat = true;
			
			if (key != null && value != null && isConcat == false) {
				for (Method method : document.getClass().getDeclaredMethods()) {
					if (method.getName().startsWith("set") && method.getName().endsWith(key)) {
						Class[] types = method.getParameterTypes();

						// 객체의 setter 파라미터 타입에 따라 Type casting
						// Casting하기 어려운 타입은 추가적으로 변환하는 코드가 필요.
						try {
							if (value == null)
								method.invoke(document, new Object[] { null });
							else {
								if (types[0].getName().equals("int"))
									method.invoke(document, Integer.parseInt(value));
								else
									method.invoke(document, value);
							}
						} catch (NumberFormatException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						}
					}
				}
				key = null;
				value = null;
				isConcat = false;
			}
			
			
			if (isKey) {
				StringBuilder sb = new StringBuilder();
				for (char temp : singleLine.toCharArray()) {
					if (temp != '[' && temp != ']') {
						sb.append(temp);
					}
				}
				key = sb.toString();
				value = null;
			} else if(isConcat) {
				value += singleLine;
			}
			else 
				value = singleLine;

			if(propertyTokenizer.hasMoreTokens() == false && key != null && value != null) {
				for (Method method : document.getClass().getDeclaredMethods()) {
					if (method.getName().startsWith("set") && method.getName().endsWith(key)) {
						Class[] types = method.getParameterTypes();

						// 객체의 setter 파라미터 타입에 따라 Type casting
						// Casting하기 어려운 타입은 추가적으로 변환하는 코드가 필요.
						try {
							if (value == null)
								method.invoke(document, new Object[] { null });
							else {
								if (types[0].getName().equals("int"))
									method.invoke(document, Integer.parseInt(value));
								else
									method.invoke(document, value);
							}
						} catch (NumberFormatException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						}
					}
				}
			}
			
		}
		return document;
	}
}
