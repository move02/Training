package reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import repos.Document;

public class TaggedReader {
	private TaggedParser taggedParser;
	
	public TaggedReader() {
		this.taggedParser = new TaggedParser();
	}
	
	public TaggedParser getTaggedParser() {
		return taggedParser;
	}

	public void setTaggedParser(TaggedParser taggedParser) {
		this.taggedParser = taggedParser;
	}

	public List<Document> readAll(String path) throws IOException {
		List<Document> documents = new ArrayList<>();
		try {
			documents = this.taggedParser.parseAll(getReader(path));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return documents;
	}

	private Reader getReader(String path) throws Exception{
    	    File initialFile = new File(path);
    	    InputStream inputStream = new FileInputStream(initialFile);
    	    
			return new InputStreamReader(inputStream, "UTF-8");
    }
}
