package app;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.univocity.parsers.tsv.TsvWriter;
import com.univocity.parsers.tsv.TsvWriterSettings;

import database.Connector;
import database.DAO;
import repos.Document;
import repos.DocumentDAO;

public class DbToFile {

	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		String path = "C:\\training\\DBnFile\\data\\new_doc.tsv";
		String jsonpath = "C:\\training\\DBnFile\\data\\json_doc.json";
		String taggedpath = "C:\\training\\DBnFile\\data\\tagged_doc.tagged";
		
		Connector mysqlConnector = new Connector("jdbc:mysql://localhost:3306/", "root", "daummove02");
		mysqlConnector.setDbName("training1");
		mysqlConnector.setTableName("DOC1");
		
		DAO<Document> dao = new DocumentDAO(mysqlConnector.connect(), mysqlConnector.getTableName());
		dao.setColNames();
		
//		dbToTsv(path, dao);
//		dbToJson(jsonpath, dao);
		dbToTagged(taggedpath, dao);
		
		long end = System.currentTimeMillis();
		
		System.out.println("걸린 시간 : " + (end-start)/(double)1000 + "sec");

	}
	
	public static void dbToTsv(String path, DAO dao) {
		File output = new File(path);
		
		TsvWriterSettings writerSettings = new TsvWriterSettings();
		writerSettings.getFormat().setLineSeparator("\n");

		writerSettings.setLineJoiningEnabled(true);

		int count = 0;
		FileWriter fw = null;
				
		try {	
			fw = new FileWriter(output);
			
			TsvWriter tsvWriter = new TsvWriter(fw, writerSettings);
			List<String> headers = dao.getColNames();
			tsvWriter.writeHeaders(headers);
			
			List<Document> selectResult = dao.select("DESC");
						
			for(Document doc : selectResult) {
				List<String> row = new ArrayList<>();
				
				for(String colname : headers) {
					Field field = doc.getClass().getDeclaredField(colname);
					field.setAccessible(true);
					Object attr = field.get(doc);
					if(attr != null)
						row.add(attr.toString());
					else
						row.add("");
				}
				
				tsvWriter.writeRow(row);
				count++;
				if(count > 1000) {
					tsvWriter.flush();
					count = 0;
				}
			}
			
			fw.close();
		} catch (IOException | IllegalAccessException | IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
	}
	
	public static void dbToJson(String path, DAO dao) {
		List<Document> selectResult = dao.select("DESC");
		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();
		
		int count = 0;
		File output = new File(path);

		FileWriter fw = null;
		try {
			fw = new FileWriter(output);
			fw.write("[");
			for(Document doc : selectResult) {
				fw.write(gson.toJson(doc).toString() + ",");
				count++;
				if(count > 1000) {
					fw.flush();
					count = 0;
				}
			}
			fw.write("]");
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void dbToTagged(String path, DAO dao) {
		List<Document> selectResult = dao.select("DESC");
		
		File output = new File(path);
		int count = 0;

		FileWriter fw = null;
		// Writer 클래스는 버퍼(메모리)에 입력값을 모두 담아두기 때문에 한계 용량이 다 차면 더 이상 사용할 수 없음.
		// 중간 writer의 buffer를 지워주어야 함.
		// 매 번 지우면 write를 하는 횟수만큼 buffer를 비우게 되어 비효율적임. 적당한 주기를 두고 지우는 것이 중요.
		try {
			fw = new FileWriter(output);
			List<String> headers = dao.getColNames();
			
			for(Document doc : selectResult) {
				fw.write("^[START]");				
				
				for(String colname : headers) {
					// 1. PropertyDescriptor 이용 (2초대)
//					try {
//						PropertyDescriptor pd = new PropertyDescriptor(colname, doc.getClass());
//						Method method = pd.getReadMethod();
//						Object attr = method.invoke(doc);
//						
//						if(attr != null) {
//							fw.write("\n[" + colname + "]\n" + attr.toString());
//						}
//						else {
//							fw.write("\n[" + colname + "]\n" + "");
//						}
//						
//					} catch (IntrospectionException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					} catch (InvocationTargetException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					
					
					// 2. Field 클래스 이용 (1초 초반대)
					try {
						Field field = doc.getClass().getDeclaredField(colname);
						field.setAccessible(true);
						Object attr = field.get(doc);
						if(attr != null) {
							fw.write("\n[" + colname + "]\n" + attr.toString());
						}
						else {
							fw.write("\n[" + colname + "]\n" + "");
						}
					} catch (NoSuchFieldException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					}
					
					// 3. 메소드 순회 (1초 중반대)
//					for(Method method : doc.getClass().getDeclaredMethods()) {
//						if(method.getName().endsWith(colname) && method.getName().startsWith("get")) {
//							Object attr = method.invoke(doc);
//							if(attr != null) {
//								fw.write("\n[" + colname + "]\n" + attr.toString());
//							}
//							else {
//								fw.write("\n[" + colname + "]\n" + "");
//							}
//						}
//					}
				}
				
				fw.write("\n^[END]\n");
				count++;
				if(count > 1000) {
					fw.flush();
					count = 0;
				}
			}
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
	}
}
