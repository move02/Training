package app;

import java.util.ArrayList;
import java.util.List;

import database.Connector;
import database.DAO;
import reader.TsvReader;
import repos.Document;
import repos.DocumentDAO;

public class FileToDB {

	public static void main(String[] args) {
		long start = System.currentTimeMillis();

		// Data File 경로
		String path = "C:\\training\\DBnFile\\data\\doc.tsv";

		Connector mysqlConnector = new Connector("jdbc:mysql://localhost:3306/", "root", "daummove02");
		mysqlConnector.setDbName("training1");
		mysqlConnector.setTableName("DOC5");

		DAO<Document> dao = new DocumentDAO(mysqlConnector.connect(), mysqlConnector.getTableName());
		dao.setColNames();
		
		fileToDB(path, dao);
		long end = System.currentTimeMillis();

		System.out.println("걸린 시간 : " + (end - start) / 1000 + "sec");

		mysqlConnector.close();
	}

	// 1. insert line by line : 362sec
//	public static void fileToDB(String path, DAO<Document> dao) {
//		TsvReader tsvReader = new TsvReader();
//		
//		List<String[]> lines = tsvReader.readFile(path);
//		
//		for(String[] line : lines) {
//			Document doc = new Document();
//			
//			doc.setSequence(Integer.parseInt(line[0]));
//			doc.setTitle(line[1]);			
//			doc.setRegDate(line[2]);
//			
//			dao.insert(doc);
//		}
//	}

	// 2. insert whole documents using batch : 19sec
//	public static void fileToDB(String path, DAO<Document> dao) {
//		TsvReader tsvReader = new TsvReader();
//		
//		List<String[]> lines = tsvReader.readFile(path);
//		dao.insert(lines);
//	}

	// 3. insert 200 documents at once using batch : 23sec
//	public static void fileToDB(String path, DAO<Document> dao) {
//		TsvReader tsvReader = new TsvReader();
//		
//		List<String[]> lines = tsvReader.readFile(path);
//		dao.insert(lines);
//	}

	// 4. insert 1000 documents at once using multiple insert query : 5~8sec
	// Connection을 늘리면 개선 가능할 듯!
	public static void fileToDB(String path, DAO<Document> dao) {
		TsvReader tsvReader = new TsvReader();

		List<String[]> lines = tsvReader.readFile(path);
		List<String[]> bundle = new ArrayList<>();

		for (String[] line : lines) {
			bundle.add(line);
			if (bundle.size() > 1000) {
				dao.insert(bundle);
				bundle.clear();
			}
		}

		dao.insert(bundle);
	}
	
	// 5. 4번 + batch processing : 5~8sec
//	public static void fileToDB(String path, DAO<Document> dao) {
//		TsvReader tsvReader = new TsvReader();
//
//		List<String[]> lines = tsvReader.readFile(path);
//		dao.insert(lines);
//	}

}
