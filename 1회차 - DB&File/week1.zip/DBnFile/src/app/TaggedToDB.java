package app;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import database.Connector;
import database.DAO;
import reader.TaggedReader;
import repos.Document;
import repos.DocumentDAO;

public class TaggedToDB {
	public static long start = System.currentTimeMillis();

	public static void main(String[] args) {

		TaggedReader taggedReader = new TaggedReader();
		String path = "C:\\training\\DBnFile\\data\\tagged_doc.tagged";

		Connector mysqlConnector = new Connector("jdbc:mysql://localhost:3306/", "root", "daummove02");
		mysqlConnector.setDbName("training1");
		mysqlConnector.setTableName("DOC2");

		DAO<Document> dao = new DocumentDAO(mysqlConnector.connect(), mysqlConnector.getTableName());
		((DocumentDAO) dao).setTabName("DOC2");
		dao.setColNames();

		try {
			taggedFileToDB(taggedReader.readAll(path), dao);
		} catch (IOException e) {
			e.printStackTrace();
		}

		long end = System.currentTimeMillis();

		System.out.println("총 걸린 시간 : " + (end - start) /(double) 1000 + "sec");

	}

	public static void taggedFileToDB(List<Document> documents, DAO<Document> dao) {
		long end = System.currentTimeMillis();

		System.out.println("파싱 걸린 시간 : " + (end - start) /(double) 1000 + "sec");
		List<String[]> bundle = new ArrayList<>();

		for (Document doc : documents) {
			String[] line = doc.memebersToStringArray();
			bundle.add(line);
			if (bundle.size() > 800) {
				dao.insert(bundle);
				bundle.clear();
			}
		}

		dao.insert(bundle);
	}

}
