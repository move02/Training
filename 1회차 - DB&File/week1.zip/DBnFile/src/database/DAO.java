package database;

import java.util.List;

import repos.Document;

public interface DAO<Obj> {
	public List<String> getColNames();

	public void setColNames();

	public void insert(Obj obj);

	public void insert(List<String[]> documents);

	public List<Obj> select(String order);

	public void delete(Obj obj);

	public void update(Obj obj, String[] args);
}
