package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connector {
	private Connection conn;
	private String url;
	private String username;
	private String password;
	private String dbName;
	private String tableName;

	public Connector() {

	}

	public Connector(String url, String username, String password) {
		this.url = url;
		this.username = username;
		this.password = password;
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Connection connect() {
		if (this.conn == null) {
			try {
				this.conn = DriverManager.getConnection(
						this.url + this.dbName + "?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false",
						this.username, this.password);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return this.conn;
	}

	public void close() {
		try {
			this.conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
