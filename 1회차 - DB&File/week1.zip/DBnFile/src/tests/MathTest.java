package tests;

public class MathTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.ceil((double)21/(double)20));
	}

}
