package tests;

import java.io.IOException;

import reader.TaggedReader;
import repos.Document;

public class TaggedTest {
	public static void main(String args[]) throws IOException {
		TaggedReader taggedReader = new TaggedReader();
		
		String path = "C:\\training\\DBnFile\\data\\temp.tagged";
		
		System.out.println("======Start reading=====");
		
		taggedReader.readAll(path);
		
		System.out.println("\n======End reading======");
	}
}
