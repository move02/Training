package tests;

public class StringTest {

	public static void main(String[] args) {
		String a = "a";
		for(int i = 1; i <= 10; i ++) {
			a += (char)('a' + i);
		}
		
		System.out.println(a);
	}

}
