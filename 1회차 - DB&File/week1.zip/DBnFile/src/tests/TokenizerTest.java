package tests;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.StringTokenizer;

public class TokenizerTest {

	public static void main(String[] args) {
		String path = "C:\\training\\DBnFile\\data\\temp.tagged";
		String body = null;
		
		try {
			BufferedReader reader = new BufferedReader(getReader(path));
			StringBuilder sb = new StringBuilder();
			
			int c = 0;
			while((c = reader.read()) != -1) {
				sb.append((char)c);
			}
			
			body = sb.toString();
			
			StringTokenizer st1 = new StringTokenizer(body, "\n");
			
			String a = st1.nextToken();
			StringTokenizer st2 = st1;
			
			String b = st1.nextToken();
			String d = st1.nextToken();

			String e = st2.nextToken();
			String f = st1.nextToken();
			
			System.out.println(a);
			System.out.println(b);
			System.out.println(d);
			System.out.println(e);
			System.out.println(f);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
	
	private static Reader getReader(String path) throws Exception{
    	    File initialFile = new File(path);
    	    InputStream inputStream = new FileInputStream(initialFile);
    	    
			return new InputStreamReader(inputStream, "UTF-8");
    }

}
