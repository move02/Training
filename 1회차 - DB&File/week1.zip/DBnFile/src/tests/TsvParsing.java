package tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;

import com.univocity.parsers.tsv.TsvParser;
import com.univocity.parsers.tsv.TsvParserSettings;

public class TsvParsing {

	public static void main(String[] args) {
		TsvParserSettings settings = new TsvParserSettings();
		settings.getFormat().setLineSeparator("\n");

		TsvParser parser = new TsvParser(settings);

		ReaderClass readerclass = new ReaderClass();
		
		String path = "C:\\training\\DBnFile\\src\\doc.tsv";
		
		try {
			List<String[]> allRows = parser.parseAll(readerclass.getReader(path));
			
			int count = 2012080;
			
			for(String[] row : allRows) {
				int seq = Integer.parseInt(row[0]);
				if(seq != count) {
					System.out.print("count : " + count + "\t");
					System.out.print(row[0] + "\t");
					System.out.print(row[1] + "\t");
					System.out.println(row[2] + "\t");
					
					count = seq;
				}
				
				count--;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

class ReaderClass {
	
	public Reader getReader(String relativePath) throws Exception{
    	    File initialFile = new File(relativePath);
    	    InputStream inputStream = new FileInputStream(initialFile);
    	    
			return new InputStreamReader(inputStream, "UTF-8");
    }
}
