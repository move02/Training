package tests;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;

import repos.Document;
import repos.Document.Order;

public class TypeTest {

	// getMethods, getDclaredMtehods는 순서를 보장하지 않음(랜덤)
	// Annotation을 이용하여 원하는 순서대로 정렬 후 사용할 것.
	public static void main(String[] args) {
		
		Document doc = new Document();
		
		Method[] methods = doc.getClass().getDeclaredMethods();
        Arrays.sort(methods, new Comparator<Method>() {
            @Override
            public int compare(Method m1, Method m2) {
                Order or1 = m1.getAnnotation(Order.class);
                Order or2 = m2.getAnnotation(Order.class);
                
                if (or1 != null && or2 != null) {
                    return or1.value() - or2.value();
                } else
                if (or1 != null && or2 == null) {
                    return -1;
                } else
                if (or1 == null && or2 != null) {
                    return 1;
                }
                return m1.getName().compareTo(m2.getName());
            }
        });
        
//        Field[] fields = doc.getClass().getDeclaredFields();
//        for(Field f : fields) {
//        	System.out.println(f.getName());
//        }
        
        String a = "asdfa";
        Object o = "qqqqwrt";
        
        String asdf = a+o;
        System.out.println(asdf);
		
//		for(Method m : methods){
//			if(m.getName().startsWith("get"))
//				System.out.println(m.getName());
//		}
	}

}
