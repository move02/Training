package tests;

import database.Connector;
import database.DAO;
import repos.Document;
import repos.DocumentDAO;

public class ColnameTest {
	public static void main(String[] args) {

		long start = System.currentTimeMillis();
		
		Connector mysqlConnector = new Connector("jdbc:mysql://localhost:3306/", "root", "daummove02");
		mysqlConnector.setDbName("training1");
		mysqlConnector.setTableName("DOC1");
		
		DAO<Document> dao = new DocumentDAO(mysqlConnector.connect(), mysqlConnector.getTableName());
		
		System.out.println(((DocumentDAO)dao).getColNames().toString());
		
		long end = System.currentTimeMillis();

		System.out.println("걸린 시간 : " + (end-start)/(double)1000 + "sec");
	}

}
