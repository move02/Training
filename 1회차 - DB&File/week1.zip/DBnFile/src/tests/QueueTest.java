package tests;

import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {
		Queue<Character> q = new LinkedList<Character>();
		
		for(int i = 0; i < 20; i++)
			q.offer((char) ('a'+i));

		while(!q.isEmpty())
			System.out.print(q.poll());
	}

}
