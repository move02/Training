package tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnTest {
	
	public static Connection conn = null;

	public static void main(String[] args) {
		String schemeName = "training1";
		String tableName = "DOC1";
		
		String url = "jdbc:mysql://localhost:3306/" + schemeName + "?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
		String id = "root";
		String pw = "daummove02";
		
		try {
			conn = DriverManager.getConnection(url, id, pw);
			
			String selectQuery = "SELECT * FROM " + tableName;
			PreparedStatement pstm = conn.prepareStatement(selectQuery);
			
			pstm.execute();
			ResultSet result = pstm.getResultSet();
			
			if(result.next()) {
				while(result.next()){
					String seq = result.getString(1);
					String title = result.getString(2);
					String date = result.getString(3);
					
					System.out.println(seq + " / " + title + " / " + date);
				}
			}
			else {
				System.out.println("None");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
