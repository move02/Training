package tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;

public class InsertTest {
	
	private static Connection conn = null;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

	public static void main(String[] args) {
		String schemeName = "training1";
		String tableName = "DOC1";
		
		String url = "jdbc:mysql://localhost:3306/" + schemeName + "?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false";
		String id = "root";
		String pw = "daummove02";
		
		
		try {
			conn = DriverManager.getConnection(url, id, pw);
			
			String insertQuery = "INSERT INTO " + tableName + " VALUES(?, ?, ?);";
			
			for(int i = 1; i < 11; i++) {
				PreparedStatement pstm = conn.prepareStatement(insertQuery);
				Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				
				pstm.setInt(1, i);
				pstm.setString(2, "title" + i);
				pstm.setString(3, sdf.format(timestamp));
				
				pstm.execute();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
