package tests;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import repos.Document;

public class PDTest {

	public static void main(String[] args) {
		Document doc = new Document(1234,"The Greatest Show Man", "1234123123");
		
		PropertyDescriptor pd = null;
		try {
			// PropertyDescriptor는 Java Bean이 한 쌍의 접근자 메소드를 통해 내보내는 하나의 속성을 기술함
			// doc 객체의 title 이라는 속성을 기술하는  PropertyDescriptor 객체를 생성
			pd = new PropertyDescriptor("TITLE", doc.getClass());
			
			Method getter = pd.getReadMethod();
			String getResult = (String) getter.invoke(doc);
			
			System.out.println("Get Result : " + getResult + "\n");
			
			Method setter = pd.getWriteMethod();
			setter.invoke(doc, "This is me");
			
			System.out.println(doc);
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IntrospectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
