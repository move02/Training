package repos;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Document {
	@Target(ElementType.METHOD)
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Order {
		int value();
	}

	// members
	private int DOC_SEQ;
	private String TITLE;
	private String REG_DT;

	// constructors
	public Document() {

	}

	public Document(int sequence, String title, String regDate) {
		this.DOC_SEQ = sequence;
		this.TITLE = title;
		this.REG_DT = regDate;
	}

	// getter & setter
	@Order(value = 1)
	public int getDOC_SEQ() {
		return DOC_SEQ;
	}

	public void setDOC_SEQ(int sequence) {
		this.DOC_SEQ = sequence;
	}

	@Order(value = 2)
	public String getTITLE() {
		return TITLE;
	}

	public void setTITLE(String title) {
		this.TITLE = title;
	}

	@Order(value = 3)
	public String getREG_DT() {
		return REG_DT;
	}

	public void setREG_DT(String regDate) {
		this.REG_DT = regDate;
	}

	// methods

	@Override
	public String toString() {
		return "Document\n[DOC_SEQ]\n" + DOC_SEQ + "\n[TITLE]\n" + TITLE + "\n[REG_DT]\n" + REG_DT;
	}

	public String[] memebersToStringArray() {
		List<Object> attrs = new ArrayList<>();

		// Document 클래스의 메소드를 가져운 뒤
		Method[] methods = this.getClass().getDeclaredMethods();
		Arrays.sort(methods, new Comparator<Method>() {
			@Override
			public int compare(Method m1, Method m2) {
				Order or1 = m1.getAnnotation(Order.class);
				Order or2 = m2.getAnnotation(Order.class);

				if (or1 != null && or2 != null) {
					return or1.value() - or2.value();
				} else if (or1 != null && or2 == null) {
					return -1;
				} else if (or1 == null && or2 != null) {
					return 1;
				}
				return m1.getName().compareTo(m2.getName());
			}
		});
		

		for (Method method : methods) {
			Object invokeResult = null;
			Class type = method.getReturnType();

			try {
				if (method.getName().startsWith("get")) {
					if (type.getName().equals("java.lang.Class"))
						continue;
					else
						invokeResult = method.invoke(this);

					attrs.add(invokeResult);
				}
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (ClassCastException e) {
				e.printStackTrace();
			}
		}

		String[] members = new String[attrs.size()];
		int i = 0;
		for (Object o : attrs) {
			String s = null;
			if (o != null) {
				if (o.getClass().getName() == "java.lang.Integer")
					s = Integer.toString((int) o);
				else
					s = o.toString();
			}
			members[i] = s;
			i++;
		}

		return members;
	}
}
