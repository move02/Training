package repos;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

import database.DAO;

public class DocumentDAO implements DAO<Document> {
	// members
	private Connection connection;
	private String tabName;
	private List<String> colNames;

	// constructor
	public DocumentDAO() {

	}

	public DocumentDAO(Connection connection, String tabName) {
		this.connection = connection;
		this.tabName = tabName;
	}

	// Getter Setter
	public String getTabName() {
		return tabName;
	}

	public void setTabName(String tabName) {
		this.tabName = tabName;
	}

	// methods

	@Override
	public List<String> getColNames() {
		return colNames;
	}

	@Override
	public void setColNames() {
		String query = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS" + " WHERE TABLE_NAME = N'" + this.tabName + "'";
		PreparedStatement pstmt = null;

		List<String> colNames = null;

		try {
			pstmt = this.connection.prepareStatement(query);

			pstmt.execute();

			ResultSet resultSet = pstmt.getResultSet();

			colNames = new ArrayList<>();

			while (resultSet.next()) {
				colNames.add(resultSet.getString(4));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		this.colNames = colNames;
	}

	// 1. insert line by line
	@Override
	public void insert(Document obj) {
		StringBuilder paramsBuilder = new StringBuilder("?");

		for (int i = 0; i < this.colNames.size() - 1; i++)
			paramsBuilder.append(", ?");

		String params = paramsBuilder.toString();
		String query = "INSERT INTO " + this.tabName + " VALUES (" + params + ")";

		PreparedStatement pstmt = null;
		try {
			pstmt = this.connection.prepareStatement(query);

			pstmt.setInt(1, obj.getDOC_SEQ());
			pstmt.setString(2, obj.getTITLE());
			pstmt.setString(3, obj.getREG_DT());

			pstmt.execute();

			System.out.println(obj.getDOC_SEQ() + " doc Inserted");
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
	}

	// 2. insert whole documents using batch
//	@Override
//	public void insert(List<String[]> documents) {
//		String query = "INSERT INTO DOC1 VALUES(?, ?, ?)";
//		
//		PreparedStatement pstmt = null;
//		try {
//			this.connection.setAutoCommit(false);
//			pstmt = this.connection.prepareStatement(query);
//			
//			for(String[] doc : documents) {
//				int i = 1;
//				
//				for(String col : doc) {
//					pstmt.setObject(i++, col);
//				}
//				
//				pstmt.addBatch();
//			}
//			
//			pstmt.executeBatch();
//			connection.commit();
//			pstmt.clearBatch();
//		} catch (SQLException e) {
//			e.printStackTrace();
//			return;
//		}
//	}

	// 3. insert 200 documents at once using batch
//	@Override
//	public void insert(List<String[]> documents) {
//		String query = "INSERT INTO DOC1 VALUES(?, ?, ?)";
//		
//		PreparedStatement pstmt = null;
//		try {
//			this.connection.setAutoCommit(false);
//			pstmt = this.connection.prepareStatement(query);
//			
//			int size = 0;
//			for(String[] doc : documents) {
//				int i = 1;
//				
//				for(String col : doc) {
//					pstmt.setObject(i++, col);
//				}
//				
//				pstmt.addBatch();
//				
//				size++;
//				
//				if(size > 200) {
//					pstmt.executeBatch();
//					connection.commit();
//					pstmt.clearBatch();
//					size = 0;
//				}
//			}
//			pstmt.executeBatch();
//			connection.commit();
//			pstmt.clearBatch();
//		} catch (SQLException e) {
//			e.printStackTrace();
//			return;
//		}
//	}

	// 4. insert 1000 documents at once using multiple insert query
	@Override
	public void insert(List<String[]> bundle) {
		StringBuilder paramsBuilder = new StringBuilder("?");

		for (int i = 0; i < this.colNames.size() - 1; i++)
			paramsBuilder.append(", ?");

		String params = paramsBuilder.toString();
		String query = "INSERT INTO " + this.tabName + " VALUES (" + params + ")";
		PreparedStatement pstmt = null;
		try {
			int i = 1;
			for (int j = 1; j < bundle.size(); j++) {
				query += ",\n(" + params + ")";
			}

			pstmt = this.connection.prepareStatement(query);
			
			for (String[] doc : bundle) {
				for (String col : doc) {
					pstmt.setObject(i++, col);
				}
			}
		
			pstmt.execute();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
	}
	
	// 5. 4번 & batch processing
//	@Override
//	public void insert(List<String[]> bundle) {
//		StringBuilder paramsBuilder = new StringBuilder("?");
//
//		for (int i = 0; i < this.colNames.size() - 1; i++)
//			paramsBuilder.append(", ?");
//
//		String params = paramsBuilder.toString();
//		String query = "INSERT INTO " + this.tabName + " VALUES (" + params + ")";
//		PreparedStatement pstmt = null;
//		
//		List<String[]> temp = new ArrayList<>();
//
//		try {
//			pstmt = this.connection.prepareStatement(null);
//
//			int i = 1;
//			for(String[] doc : bundle) {
//				temp.add(doc);
//				
//				if(temp.size() > 1000) {	
//					for (int j = 1; j < temp.size(); j++) {
//						query += ",\n(" + params + ")";
//					}
//					
//					for (String[] dd : temp) {
//						for (String col : dd) {
//							pstmt.setObject(i++, col);
//						}
//					}
//					
//					pstmt.addBatch(query);
//					query = "INSERT INTO " + this.tabName + " VALUES (" + params + ")";
//					temp.clear();
//				}
//			}
//			
//			if(temp.size() > 0) {
//				query = "INSERT INTO " + this.tabName + " VALUES (" + params + ")";
//				
//				for (int j = 1; j < temp.size(); j++) {
//					query += ",\n(" + params + ")";
//				}
//				
//				for (String[] dd : temp) {
//					for (String col : dd) {
//						pstmt.setObject(i++, col);
//					}
//				}
//				
//				pstmt.addBatch(query);
//			}
//			
//			pstmt.executeBatch();
//			pstmt.close();
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//			return;
//		}
//		
//	}

	@Override
	public List<Document> select(String order) {
		String query = "SELECT * FROM " + this.tabName + " ORDER BY DOC_SEQ " + order;

		PreparedStatement pstmt = null;
		List<Document> result = new ArrayList<>();

		try {
			pstmt = this.connection.prepareStatement(query);
			pstmt.execute();
			ResultSet resultSet = pstmt.getResultSet();

			while (resultSet.next()) {
				Document doc = new Document();
				
				doc.setDOC_SEQ(resultSet.getInt(1));
				doc.setTITLE(resultSet.getString(2));
				doc.setREG_DT(resultSet.getString(3));

				for (String colname : this.getColNames()) {
					
					Field field = doc.getClass().getDeclaredField(colname);
					field.setAccessible(true);
					field.set(doc,  resultSet.getObject(colname));
//					for (Method method : doc.getClass().getDeclaredMethods()) {
//						if (method.getName().endsWith(colname) && method.getName().startsWith("set"))
//							method.invoke(doc, resultSet.getObject(colname));
//					}
				}

				result.add(doc);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public void delete(Document obj) {

	}

	@Override
	public void update(Document obj, String[] args) {

	}

}
