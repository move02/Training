package com.ds.move02.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "tb_press", indexes = {
        @Index(columnList = "id", name = "press_id")
})
public class Press implements Serializable{
	private static final long serialVersionUID = 1L; 
	
	@Id
	@Column(name="id", nullable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Size(max=3)
	private int id;
	
	@Column(name="name", nullable=false, unique=true)
	@Size(max=20)
	private String name;
	
	@Column(name="base_url", nullable=false)
	@Size(max=50)
	private String baseUrl;
	
    @OneToMany(mappedBy="press", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Journalist> journalists;
    
    @OneToMany(mappedBy="press", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<News> newses;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public List<Journalist> getJournalists() {
		return journalists;
	}

	public void setJournalists(List<Journalist> journalists) {
		this.journalists = journalists;
	}

	public List<News> getNewses() {
		return newses;
	}

	public void setNewses(List<News> newses) {
		this.newses = newses;
	}
    
    
}
