package com.ds.move02.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.SortableField;
import org.hibernate.search.annotations.TermVector;

@Entity
@Table(name = "tb_news", indexes = { @Index(columnList = "id", name = "news_id") })
@Indexed
public class News implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Size(max = 8)
	private int id;

	@Column(name = "nid")
	@Size(max = 50)
	private String nid;

	@Column(name = "published_date", nullable = false, columnDefinition = "datetime")
    @Field(name = "published_date") // <== Add this
    @SortableField(forField = "published_date")  // <== And this
	private LocalDateTime published_date;

	@Column(name = "created_date", nullable = false, columnDefinition = "datetime")
	@CreationTimestamp
	private LocalDateTime created_date;

	@Column(name = "title", nullable = false)
	@Size(max = 100)
	@Field
	private String title;

	@Column(name = "body", nullable = false, columnDefinition = "text")
	@Field(termVector = TermVector.YES)
	private String body;

	@Column(name = "url", nullable = false)
	@Size(max = 100)
	private String url;

	@ManyToOne
	@JoinColumn(name = "press_id", nullable = false)
	private Press press;

	@ManyToOne
	@JoinColumn(name = "journalist_id", nullable = false)
	private Journalist journalist;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "news_category", joinColumns = @JoinColumn(name = "news_id"), inverseJoinColumns = @JoinColumn(name = "category_id"))
	private List<Category> categories = new ArrayList<>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNid() {
		return nid;
	}

	public void setNid(String nid) {
		this.nid = nid;
	}

	public LocalDateTime getPublished_date() {
		return published_date;
	}

	public void setPublished_date(LocalDateTime published_date) {
		this.published_date = published_date;
	}

	public LocalDateTime getCreated_date() {
		return created_date;
	}

	public void setCreated_date(LocalDateTime created_date) {
		this.created_date = created_date;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Press getPress() {
		return press;
	}

	public void setPress(Press press) {
		this.press = press;
	}

	public Journalist getJournalist() {
		return journalist;
	}

	public void setJournalist(Journalist journalist) {
		this.journalist = journalist;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
}
