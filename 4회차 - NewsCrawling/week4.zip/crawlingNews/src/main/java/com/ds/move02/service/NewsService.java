package com.ds.move02.service;

import java.util.List;

import com.ds.move02.model.News;

public interface NewsService {
	public long countNewses(String keyword, String category, int press, int journalist);
    public List < News> getNewses(String keyword, String category, int press, int journalist);
    public News getNews(int theId);
    public void indexing();
}
