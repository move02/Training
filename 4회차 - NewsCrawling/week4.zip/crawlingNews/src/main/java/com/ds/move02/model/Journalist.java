package com.ds.move02.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

@Entity
@Table(name = "tb_journalist", indexes = {
        @Index(columnList = "id", name = "journalist_id"),
        @Index(columnList = "name", name = "journalist_name")
})
public class Journalist implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id", nullable=false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Size(max=6)
	private int id;
	
	@Column(name="name", nullable=false, unique=true)
	@Size(max=20)
	private String name;
	
	@Column(name="email")
	@Email
	@Size(max=30)
	private String email;
	
	@Column(name="jid", unique=true)
	@Size(max=30)
	private String jid;

    @ManyToOne
    @JoinColumn(name = "press_id", nullable = false)
    private Press press;

    @OneToMany(mappedBy="journalist", cascade=CascadeType.DETACH)
    private List<News> newses;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJid() {
		return jid;
	}

	public void setJid(String jid) {
		this.jid = jid;
	}

	public Press getPost() {
		return press;
	}

	public void setPost(Press press) {
		this.press = press;
	}
    
    
}
