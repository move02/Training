package com.ds.move02.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.FullTextSession;
import org.hibernate.search.Search;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.query.dsl.QueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ds.move02.model.News;

@Repository
public class NewsDAOImpl implements NewsDAO {
	
    @Autowired
    private SessionFactory sessionFactory;

	@Override
	public long countNewses(String keyword, int category, int press, int journalist) {
		Session session = sessionFactory.getCurrentSession();
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		List<News> result = null;
		if(keyword != null) {
			QueryBuilder queryBuilder = fullTextSession.getSearchFactory() 
			  .buildQueryBuilder()
			  .forEntity(News.class)
			  .get();
			
			org.apache.lucene.search.Query fuzzyQuery = queryBuilder
					  .keyword()
					  .fuzzy()
					  .withEditDistanceUpTo(1)
					  .withPrefixLength(0)
					  .onField("body")
					  .matching(keyword)
					  .createQuery();
			
			Query hibQuery = fullTextSession.createFullTextQuery(fuzzyQuery, News.class);
			
			result = hibQuery.getResultList();
		} else {
			String plainQuery = "from News order by published_date desc";
			Query query = session.createQuery(plainQuery);
			
			result = query.getResultList();			
		}
    	return result.size();
	}

	public List<News> getNewses(String keyword, int category, int press, int journalist) {
		Session session = sessionFactory.getCurrentSession();
		FullTextSession fullTextSession = Search.getFullTextSession(session);
		 
		QueryBuilder queryBuilder = fullTextSession.getSearchFactory() 
		  .buildQueryBuilder()
		  .forEntity(News.class)
		  .get();
		
		List<News> result = null;
		
		if(keyword != null) {
			org.apache.lucene.search.Query fuzzyQuery = queryBuilder
					  .keyword()
					  .fuzzy()
					  .withEditDistanceUpTo(1)
					  .withPrefixLength(0)
					  .onField("body")
					  .matching(keyword)
					  .createQuery();
			
			org.apache.lucene.search.Sort sort = queryBuilder.sort()
					    .byField("published_date").desc() // Descending order
					  .createSort();
			
	        FullTextQuery hibQuery = fullTextSession.createFullTextQuery(fuzzyQuery, News.class);
			
	        hibQuery.setSort(sort);
			
			result = hibQuery.getResultList();
		} else {
			String plainQuery = "from News order by published_date desc";
			Query query = session.createQuery(plainQuery);
			
			result = query.getResultList();
		}
		
		return result;
	}
	
	public void indexing() {
    	Session session = sessionFactory.getCurrentSession();
    	FullTextSession fullTextSession = org.hibernate.search.Search.getFullTextSession(session);
    	try {
			fullTextSession.createIndexer().startAndWait();
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
	}
	
	
//	@Override
//	public List<News> getNewses(String keyword, int category, int press, int journalist) {
//    	Session session = sessionFactory.getCurrentSession();
//    	List<News> result = null;
//       	
//       	try {
//    		String hql = null;
//    		Category cate = null;
//    		Press pre = null;
//    		Journalist jour = null;
//    		
//    		
//    		if(keyword == null && category == 0 && press == 0 & journalist == 0) {
//    			hql = "from News news";
//    			query = session.createQuery(hql);
//    		} else {
//    			hql = "from News news where news.id >= 1";
//    			if(keyword != null) {
//    				hql += " and news.title like %:keyword% or  news.body like %:keyword2%";
//    			}
//    			if(category != 0) {
//    				cate =  (Category)session.get(Category.class, category);
//    				hql += " and news.category like %:cate%";
//    			}
//    			if(press != 0) {
//    				pre =  (Press)session.get(Press.class, press);
//    				hql += " and news.press like %:pre%";
//    			}
//    			if(journalist != 0) {
//    				jour = (Journalist)session.get(Journalist.class, journalist);
//    				hql += " and news.journalist like %:jour%";
//    			}
//    			
//    			query = session.createQuery(hql);
//    			if(keyword != null) {
//    				query.setParameter("keyword", keyword);
//    				query.setParameter("keyword2", keyword);
//    			}
//    			if(cate != null)
//    				query.setParameter("cate", cate);
//    			if(pre != null)
//    				query.setParameter("pre", pre);
//    			if(jour != null)
//    				query.setParameter("jour", jour);
//
//    		}
//
//			result = query.getResultList();
//    		
//    	} catch(HibernateException e) {    		
//    		e.printStackTrace();
//    	}
//		return result;
//	}

	@Override
	public News getNews(int theId) {
        Session currentSession = sessionFactory.getCurrentSession();
        News news = currentSession.get(News.class, theId);
		
		Hibernate.initialize(news.getJournalist());
		Hibernate.initialize(news.getPress());
		Hibernate.initialize(news.getCategories());
        return news;
	}

}
