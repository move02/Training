package com.ds.move02.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ds.move02.dao.NewsDAO;
import com.ds.move02.model.News;

@Service
public class NewsServiceImpl implements NewsService {

	@Autowired
	NewsDAO newsDAO;
	
	@Transactional
	public long countNewses(String keyword, String category, int press, int journalist) {
		if(category == null)
			return newsDAO.countNewses(keyword, 0, press, journalist);
		else if(category.equals("movie"))
			return newsDAO.countNewses(keyword, 1, press, journalist);
		else if(category.equals("sports"))
			return newsDAO.countNewses(keyword, 2, press, journalist);
		else
			return newsDAO.countNewses(keyword, 0, press, journalist);
	}

	@Transactional
	public List<News> getNewses(String keyword, String category, int press, int journalist) {
		if(category == null)
			return newsDAO.getNewses(keyword, 0, press, journalist);
		else if(category.equals("movie"))
			return newsDAO.getNewses(keyword, 1, press, journalist);
		else if(category.equals("sports"))
			return newsDAO.getNewses(keyword, 2, press, journalist);
		else
			return newsDAO.getNewses(keyword, 0, press, journalist);
	}

	@Transactional
	public News getNews(int theId) {
		return newsDAO.getNews(theId);
	}
	
	@Transactional
	public void indexing() {
		newsDAO.indexing();
	}

}
