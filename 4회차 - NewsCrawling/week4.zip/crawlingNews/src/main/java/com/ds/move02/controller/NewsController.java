package com.ds.move02.controller;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.ds.move02.model.Category;
import com.ds.move02.model.News;
import com.ds.move02.service.NewsService;

@Controller
@RequestMapping("/news")
public class NewsController {
	@Autowired
	NewsService newsService;
	
	@PostConstruct
	public void initIndexing(){
		newsService.indexing();
	}
	
	@GetMapping("/")
	public String home(Model model, @RequestParam(required = false) String keyword) {
		long count = newsService.countNewses(keyword, null, 0, 0);
		List<News> newses = newsService.getNewses(keyword, null, 1, 1);

		model.addAttribute("keyword", keyword);
		model.addAttribute("count", count);
		model.addAttribute("newses", newses);
		return "home";
	}
	
	@GetMapping("/{newsId}")
	public String show(Model model, @PathVariable int newsId) {
		News news = newsService.getNews(newsId);
		
		List<Category> categories = news.getCategories();
		
		String hashTagUrl = "http://webtool.cusis.net/wp-pages/make-tag/lib/klt/makeTag.php";
		
		MultiValueMap<String, String> reqBody = new LinkedMultiValueMap<>();
		reqBody.add("content", news.getBody());
		reqBody.add("optionMakeTag", "1");
		reqBody.add("option2byte", "true");
		
        final HttpHeaders headers = new HttpHeaders();
        headers.set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36");

        HttpEntity<MultiValueMap> request = new HttpEntity<MultiValueMap>(reqBody, headers);

		RestTemplate restTemplate = new RestTemplate();
//		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        
		ResponseEntity<String> responseEntity = restTemplate.postForEntity(hashTagUrl, request, String.class);
		
		if(responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.hasBody()) {
			String body = responseEntity.getBody();
			
			String[] tagList = body.split(" ");
			String[] top10 = new String[10];
			for(int i = 0; i < 10; i++) {
				top10[i] = tagList[i];
			}
			model.addAttribute("hashtag", top10);
		}
		
		model.addAttribute("journalist", news.getJournalist());
		model.addAttribute("press", news.getPress());
		model.addAttribute("news", news);
		model.addAttribute("categories", categories);
		return "show";
	}
}

