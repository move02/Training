package com.ds.move02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D3apiApplicationTests {

	@Test
	void contextLoads() {
	}

}
