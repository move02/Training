package com.ds.move02.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ds.move02.util.ResponseResolver;
import com.ds.move02.util.RestTemplateUtil;
import com.ds.move02.util.TM2APIUtil;
import com.google.gson.JsonObject;

@RestController
@RequestMapping("/api")
public class APIController {
	@GetMapping("/result")
	@CrossOrigin 
	public String apiResult(@RequestParam(name="start", required=true, defaultValue="20190101") String start,
			@RequestParam(name="end", required=true, defaultValue="20191111") String end,
			@RequestParam(name="keyword", required=true, defaultValue="아이폰") String keyword,
			@RequestParam(name="source", required=true, defaultValue="community") String source) {		
		JsonObject result = new JsonObject();
		
		TM2APIUtil tm2Util = new TM2APIUtil();
		
		LocalDate startDate = null;
		LocalDate endDate = null;
		
		try {
			startDate = LocalDate.parse(start, DateTimeFormatter.BASIC_ISO_DATE);
			endDate = LocalDate.parse(end, DateTimeFormatter.BASIC_ISO_DATE);
		} catch (DateTimeParseException e){
			JsonObject temp = new JsonObject();
			temp.addProperty("msg", "invalid date string");
			return temp.toString();
		}
		
		tm2Util.setStartDate(startDate);
		tm2Util.setEndDate(endDate);
		tm2Util.setKeyword(keyword);
		
		// Source setting
		tm2Util.setSource(source);
		
		String url = tm2Util.buildUrl();
		
		RestTemplateUtil rtUtil = new RestTemplateUtil(new RestTemplate());
		System.out.println(url);
		ResponseEntity<String> responseEntity = rtUtil.getResponse(url);
		
		if(responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.hasBody()) {
			ResponseResolver resolver = new ResponseResolver();
			result = resolver.resolveResponse(responseEntity);
		} else {
			JsonObject temp = new JsonObject();
			temp.addProperty("msg", "api response error");
			return temp.toString();
		}
		
		return result.toString();
	}
}
