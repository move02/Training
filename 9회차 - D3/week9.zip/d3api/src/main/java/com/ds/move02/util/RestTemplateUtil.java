package com.ds.move02.util;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestTemplateUtil {
	private static RestTemplate restTemplate;
	
	@Autowired
	public RestTemplateUtil(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
	
	public static ResponseEntity<String> getResponse(String url){
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Map<String, String>> httpEntity = new HttpEntity<Map<String, String>>(headers);

        return restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);
	}

}
