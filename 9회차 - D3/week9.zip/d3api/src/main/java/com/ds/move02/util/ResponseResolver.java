package com.ds.move02.util;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Component("responseResolver")
public class ResponseResolver {
	public JsonObject resolveResponse(ResponseEntity<String> entity) {
		JsonObject result = new JsonObject();

		JsonParser parser = new JsonParser();
		
		JsonElement whole = parser.parse(entity.getBody());
		JsonObject wholeObj = whole.getAsJsonObject();
		
		String label = wholeObj.get("label").getAsString();
		Integer frequency = wholeObj.get("frequency").getAsInt();
		Integer negative = wholeObj.get("negative").getAsInt();
		Integer positive = wholeObj.get("positive").getAsInt();

		result.addProperty("keyword", label);
		result.addProperty("frequency", frequency);
		result.addProperty("negative", negative);
		result.addProperty("positive", positive);
		
		JsonArray childList = wholeObj.get("childList").getAsJsonArray();
		JsonArray newChildList = new JsonArray();
		
		for(JsonElement row : childList) {
			JsonObject rowObj = row.getAsJsonObject();
			JsonObject newChild = new JsonObject();
			
			String rowLabel = rowObj.get("label").getAsString();
			Integer rowFrequency = rowObj.get("frequency").getAsInt();
			Integer rowScore = rowObj.get("score").getAsInt();
			Integer rowNegative = rowObj.get("negative").getAsInt();
			Integer rowPositive = rowObj.get("positive").getAsInt();

			JsonArray children = parseChildList(rowObj.get("childList"));
			
			newChild.addProperty("label", rowLabel);
			newChild.addProperty("frequency", rowFrequency);
			newChild.addProperty("score", rowScore);
			newChild.addProperty("negative", rowNegative);
			newChild.addProperty("positive", rowPositive);
			newChild.add("children", children);
			
			newChildList.add(newChild);
		}
		
		result.add("childList", newChildList);
		
		return result;
	}
	
	private JsonArray parseChildList(JsonElement element) {
		JsonArray result = new JsonArray();
		
		JsonArray children = element.getAsJsonArray();
		
		for(JsonElement child : children) {
			JsonObject obj = child.getAsJsonObject();
			if(obj.get("label").getAsString().equals("-"))
				continue;
			obj.remove("search_keyword");
			obj.remove("categoryList");
			
//			String childLabel = obj.get("label").getAsString();
//			String childPolarity = obj.get("polarity").getAsString();
//			Integer childScore = obj.get("score").getAsInt();
//			Integer rowPositive = obj.get("frequency").getAsInt();
			
			result.add(obj);
		}
		
		return result; 
	}
}
