package com.move02.board.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Post;

public interface PostService {
	public long countPosts(String keyword);

    public List < Post > getPosts(int firstResult, int maxResult);
    
    public List < Post > getPosts(int firstResult, int maxResult, String keyword);

    public void savePost(Post thePost);
    
    public void savePost(Post thePost, MultipartFile[] files);

    public Post getPost(int theId);

    public void deletePost(int theId);
}