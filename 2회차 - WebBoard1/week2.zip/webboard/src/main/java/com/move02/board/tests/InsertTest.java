package com.move02.board.tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertTest {
	
	public static void main(String[] args) {
		Connection connection = null;

		try {
			connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/training2?characterEncoding=UTF-8&serverTimezone=UTC&useSSL=false",
					"root", "daummove02");
			String sql = "insert into t_posts(author, content, title) values (?, ?, ?)";
			PreparedStatement pstmt = null;
			connection.setAutoCommit(false);
			pstmt = connection.prepareStatement(sql);
			
			for(int i = 0; i < 100; i++) {
				pstmt.setString(1, "author" + (i%10));
				pstmt.setString(2, "This is " + i + "th content." + (char)i);
				pstmt.setString(3, "title" + (i%10));
				pstmt.addBatch();
				System.out.println(i + "added");
			}
			
			pstmt.executeBatch();
			connection.commit();
			pstmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
