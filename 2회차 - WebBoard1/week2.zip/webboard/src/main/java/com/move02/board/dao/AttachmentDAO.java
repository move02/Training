package com.move02.board.dao;

import com.move02.board.model.Attachment;

public interface AttachmentDAO {
	public Attachment getAttachment(int attachId);
	public Attachment deleteAttachment(int attachId);
}
