package com.move02.board.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "t_posts")
public class Post implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "author")
	@Size(max = 40, message = "{post.author.invalid}")
	@NotEmpty(message = "Please Enter author name")
	private String author;

	@Column(name = "title")
	@Size(max = 100, message = "{post.title.invalid}")
	@NotEmpty(message = "Please Enter post's title")
	private String title;

	@Column(name = "content", columnDefinition = "text")
	private String content;
	
	@Column(name = "created_at", nullable = false, columnDefinition = "datetime default sysdate()")
	@CreationTimestamp
	private LocalDateTime createdAt;
	
	@Column(name = "updated_at", nullable = false, columnDefinition = "datetime default sysdate()")
	@UpdateTimestamp
	private LocalDateTime updatedAt;

    @OneToMany(mappedBy="post", cascade=CascadeType.ALL, orphanRemoval=true)
    private Set<Attachment> attachments;
 

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Set<Attachment> getAttachments() {
		return attachments;
	}

	public void setAttachments(Set<Attachment> attachments) {
		this.attachments = attachments;
	}

	@Override
	public String toString() {
		String attachString = new String();
		
		if(this.attachments != null) {
			for(Attachment att : this.attachments) {
				attachString += (att.getOriginalName() + "//");
			}
		} else {
			attachString = "";
		}
		
		
		return "Post [id=" + id + ", author=" + author + ", title=" + title + ", content=" + content + ", createdAt="
				+ createdAt + ", updatedAt=" + updatedAt + ", attachments=" + attachString
				+ "]";
	}
	
//    public void addAttachment(Attachment attachment) {
//    	this.attachments.add(attachment);
//    	attachment.setPost(this);
//    }
// 
//    public void removeAttachment(Attachment attachment) {
//        this.attachments.remove(attachment);
//        attachment.setPost(null);
//    }
	
	
}