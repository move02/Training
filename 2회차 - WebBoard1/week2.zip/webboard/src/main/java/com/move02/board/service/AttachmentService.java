package com.move02.board.service;

import com.move02.board.model.Attachment;

public interface AttachmentService {
	public Attachment getAttachment(int attachId);
	public void deleteAttachment(int attachId);
	public void deleteAttachmentFile(String storedName);
}
