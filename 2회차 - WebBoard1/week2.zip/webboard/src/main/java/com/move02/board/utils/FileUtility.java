package com.move02.board.utils;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.multipart.MultipartFile;

@Component("fileUtility")
public class FileUtility implements ServletContextAware{

	@Autowired
    private ServletContext servletContext;
    
	public String saveFile(MultipartFile file) {
		String ogName = file.getOriginalFilename();
		String fileExt = ogName.substring((ogName.lastIndexOf(".")));

        String newFileName = RandomStringUtils.random(32, true, true) + fileExt;
        
        try {
			String storePath = servletContext.getRealPath("/resources/") + "uploads/";
			File storeFile = new File(storePath, newFileName);
			
			file.transferTo(storeFile);
			
			System.out.println("File Saved succesfully. Saved path : " + storePath);
		} catch (IllegalStateException e) {
			e.printStackTrace();
			System.out.println("Failed to Saving file because of IllegalStateException");
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Failed to Saving file.");
		}

		return newFileName;
	}
	
	public void removeFile(String storedName) {
        try {
			String storePath = servletContext.getRealPath("/resources/") + "uploads/";
			File storeFile = new File(storePath + storedName);
			
			storeFile.delete();
			System.out.println("File removed succesfully. Saved path : " + storePath);
			
		} catch (IllegalStateException e) {
			e.printStackTrace();
			System.out.println("Failed to remove file because of IllegalStateException");
		}
	}
	
	

	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;		
	}
}
