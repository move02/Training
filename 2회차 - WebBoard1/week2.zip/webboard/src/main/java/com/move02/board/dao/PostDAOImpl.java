package com.move02.board.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.move02.board.model.Attachment;
import com.move02.board.model.Post;

@Repository
public class PostDAOImpl implements PostDAO {
    @Autowired
    private SessionFactory sessionFactory;
    
    public long countPosts(String keyword) {
    	long total = 0;
    	Session session = sessionFactory.getCurrentSession();
    	try {
    		CriteriaBuilder cb = session.getCriteriaBuilder();
    		CriteriaQuery<Long> cq = cb.createQuery(Long.class);
    		
            Root<Post> root = cq.from(Post.class);
    		
    		cq.select(cb.count(root));
    		if(keyword != null)
    			cq.where(cb.like(root.get("title"), "%" + keyword + "%"));
    		
    		total = (Long) session.createQuery(cq).getSingleResult();
    		
    	} catch(HibernateException e) {    		
    		e.printStackTrace();
    	}
    	
    	return total;
    }
    
    public List<Post> getPosts(int firstResult, int maxResult) {
        Session session = sessionFactory.getCurrentSession();
        List<Post> posts = null;
        
        try {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<Post> cq = cb.createQuery(Post.class);
            
            Root<Post> root = cq.from(Post.class);
    		cq.orderBy(cb.desc(root.get("id")));
    	    
            Query query = session.createQuery(cq);
            
            query.setFirstResult(firstResult);
            query.setMaxResults(maxResult);
            
            posts = query.getResultList();
        } catch (HibernateException e) {
    		
            e.printStackTrace();
        }
        
        return posts;
    }
    
    
    public List<Post> getPosts(int firstResult, int maxResult, String keyword) {
        Session session = sessionFactory.getCurrentSession();
        List<Post> posts = null;
        
        try {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<Post> cq = cb.createQuery(Post.class);
            
            Root<Post> root = cq.from(Post.class);
            
    		cq.where(cb.like(root.get("title"), "%" + keyword + "%"))
    				.orderBy(cb.desc(root.get("createdAt")), cb.desc(root.get("id")));
    	    
            Query query = session.createQuery(cq);
            
            query.setFirstResult(firstResult);
            query.setMaxResults(maxResult);
            
            posts = query.getResultList();
        } catch (HibernateException e) {
    		
            e.printStackTrace();
        }
        
        return posts;
    }

    
    public Post deletePost(int id) {
        Session session = sessionFactory.getCurrentSession();
        Post post = session.byId(Post.class).load((long)id);
        
        Hibernate.initialize(post.getAttachments());
        session.delete(post);
        
        return post;
    }

    
    public void savePost(Post thePost) {
        Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(thePost);
    }
    
    
    public void savePost(Post thePost, Set<Attachment> attachments) {
        Session currentSession = sessionFactory.getCurrentSession();
        currentSession.saveOrUpdate(thePost);
        
        for(Attachment at : attachments) {
        	currentSession.saveOrUpdate(at);
        }
    }


    public Post getPost(int theId) {
        Session currentSession = sessionFactory.getCurrentSession();
        Post thePost = currentSession.get(Post.class, (long)theId);
        Hibernate.initialize(thePost.getAttachments());
        return thePost;
    }
}
