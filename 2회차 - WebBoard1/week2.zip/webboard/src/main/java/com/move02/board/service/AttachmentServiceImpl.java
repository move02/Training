package com.move02.board.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.move02.board.dao.AttachmentDAO;
import com.move02.board.model.Attachment;
import com.move02.board.utils.FileUtility;

@Service
public class AttachmentServiceImpl implements AttachmentService {
	
	@Autowired
	FileUtility fileUtils;
	
	@Autowired
	AttachmentDAO attachmentDAO;
	
	@Transactional
	public Attachment getAttachment(int attachId) {
		return attachmentDAO.getAttachment(attachId);
	}
	
	@Transactional
	public void deleteAttachment(int attachId) {
		Attachment attachment = attachmentDAO.deleteAttachment(attachId);
		deleteAttachmentFile(attachment.getStoredName());
	}
	
	public void deleteAttachmentFile(String storedName) {		
		fileUtils.removeFile(storedName);
	}


}
