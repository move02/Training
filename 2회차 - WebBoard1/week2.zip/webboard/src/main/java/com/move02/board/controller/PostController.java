package com.move02.board.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Post;
import com.move02.board.service.PostService;
import com.move02.board.utils.PageUtils;

@Controller
@RequestMapping("/post")
public class PostController {

	@Autowired
	private PostService postService;
	
	@Autowired
	private HttpServletRequest request;
	
	@GetMapping("/")
	public String listPosts(Model theModel, @RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "1") int range,
			@RequestParam(required = false) String keyword,
			HttpServletResponse response) {

		long count = postService.countPosts(keyword);
		PageUtils pagination = new PageUtils();

		pagination.pageInfo(page, range, count, keyword);
		
		int startVal = (pagination.getListSize() * (page - 1));
		long numbering = count - startVal;
		
		
		List<Post> thePosts = null;
		if(keyword == null) {
			thePosts = postService.getPosts(startVal, pagination.getListSize());
		}else {
			thePosts = postService.getPosts(startVal, pagination.getListSize(), keyword);
		}
		
		Cookie pageCookie = null;
		Cookie rangeCookie = null;
		Cookie keywordCookie = null;
		
		pageCookie = new Cookie("page", Integer.toString(page));
		pageCookie.setMaxAge(10*60*60);
		rangeCookie = new Cookie("range", Integer.toString(range));
		rangeCookie.setMaxAge(10*60*60);
		keywordCookie = new Cookie("keyword", keyword);
		keywordCookie.setMaxAge(10*60*60);
		
		response.addCookie(pageCookie);
		response.addCookie(rangeCookie);
		response.addCookie(keywordCookie);

		theModel.addAttribute("numbering", numbering);
		theModel.addAttribute("pagination", pagination);
		theModel.addAttribute("posts", thePosts);
		
		return "post/index";
	}

	@GetMapping("/{postId}")
	public String showPost(Model theModel, @PathVariable("postId") int theId) {
		Post post = postService.getPost(theId);
		Hibernate.initialize(post.getAttachments());
		
		theModel = retrieveCookie(theModel);
		
		String resourcePath = getBaseURL(request)+"/resources/uploads/";
		theModel.addAttribute("resourcePath", resourcePath);
		theModel.addAttribute("post", post);
		return "post/show";
	}

	@GetMapping("/new")
	public String showFormForAdd(Model theModel) {
		Post thePost = new Post();
		theModel = retrieveCookie(theModel);
		theModel.addAttribute("post", thePost);
		return "post/post-form";
	}

	@PostMapping("/save")
	public String savePost(@ModelAttribute("post") Post thePost, @RequestParam("multiFiles") MultipartFile[] files) {
		Hibernate.initialize(thePost.getAttachments());
		int totalSize = 0;
		
		if(thePost.getAttachments() != null)
			totalSize = files.length + thePost.getAttachments().size();
		else
			totalSize = files.length;
		
		thePost.setUpdatedAt(LocalDateTime.now());
		System.out.println("total Size : " + totalSize);
		if(totalSize  > 3) {
			// error
			System.out.println("Too many Files");
			return "redirect:/post/update/" + thePost.getId();
		}
		else if (totalSize > 0)
			postService.savePost(thePost, files);
		else
			postService.savePost(thePost);

		return "redirect:/post/" + thePost.getId();
	}

	@GetMapping("/update/{postId}")
	public String showFormForUpdate(@PathVariable("postId") int theId, Model theModel) {
		Post thePost = postService.getPost(theId);
		Hibernate.initialize(thePost.getAttachments());

		theModel = retrieveCookie(theModel);
		theModel.addAttribute("post", thePost);
		theModel.addAttribute("isupdate", true);
		theModel.addAttribute("attachements", thePost.getAttachments());
		return "post/post-form";
	}

//	@DeleteMapping("/delete/{postId}")
	@GetMapping("/delete/{postId}")
	public String deletePost(@PathVariable("postId") int theId) {
		postService.deletePost(theId);
				
		return "redirect:/post/";
	}
	
//	private Map<String, String> retrieveCookie(HttpServletRequest request){
//
//		String page = null, range = null, keyword = null;
//		Map<String, String> cookieMap = new HashMap<>();
//		
//		for(Cookie cookie : request.getCookies()) {
//			if(cookie.getName().equals("page")) {
//				cookieMap.put("page", page);
//			}
//			else if(cookie.getName().equals("range")) {
//				cookieMap.put("range", range);
//			}
//			else if(cookie.getName().equals("keyword")) {
//				cookieMap.put("keyword", keyword);
//			}
//		}
//		
//		return cookieMap;
//	}
	
	private Model retrieveCookie(Model theModel) {
		int page = 1, range = 1;
		String keyword = null;
		
		for(Cookie cookie : request.getCookies()) {
			if(cookie.getName().equals("page")) {
				page = Integer.parseInt(cookie.getValue());
			}
			else if(cookie.getName().equals("range")) {
				range = Integer.parseInt(cookie.getValue());
			}
			else if(cookie.getName().equals("keyword")) {
				keyword = cookie.getValue();
			}
		}
		
		theModel.addAttribute("page", page);
		theModel.addAttribute("range", range);
		theModel.addAttribute("keyword", keyword);
		
		return theModel;
	}
	
    //get base URL
    private String getBaseURL(HttpServletRequest request){
        return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
    }
}