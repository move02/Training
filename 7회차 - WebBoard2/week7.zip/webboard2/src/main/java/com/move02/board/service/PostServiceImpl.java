package com.move02.board.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.move02.board.dao.PostDAO;
import com.move02.board.model.Attachment;
import com.move02.board.model.Post;
import com.move02.board.utils.FileUtility;

@Service
class PostServiceImpl implements PostService {

    @Autowired
    private PostDAO postDAO;

    @Autowired
    private FileUtility fileUtility;
    
    @Autowired
    private AttachmentService attachmentService;
    
    @Transactional
    public long countPosts(String keyword, String searchBy) {
    	return postDAO.countPosts(keyword, searchBy);
    }
    
    @Transactional
	public List<Post> getPosts(int firstResult, int maxResult, String orderBy) {
		return postDAO.getPosts(firstResult, maxResult, orderBy);
	}
    
    @Transactional
	public List<Post> getPosts(int firstResult, int maxResult, String keyword, String orderBy, String searchBy) {
		return postDAO.getPosts(firstResult, maxResult, keyword, orderBy, searchBy);
	}

    @Transactional
	public void savePost(Post thePost) {
    	thePost.setContent(escapeScriptTag(thePost.getContent()));
		postDAO.savePost(thePost);
	}
    
    @Transactional
	public void savePost(Post thePost, MultipartFile[] files) {
    	Set<Attachment> attachements = new HashSet<>();
    	
    	// save files & add attachments to post
        for(MultipartFile mf : files) {
            String storedName = fileUtility.saveFile(mf);
            
        	Attachment attachment = new Attachment();
        	attachment.setOriginalName(mf.getOriginalFilename());
        	attachment.setStoredName(storedName);
        	attachment.setType(mf.getContentType());
        	attachment.setPost(thePost);
        	
        	attachements.add(attachment);
        }
    	thePost.setContent(escapeScriptTag(thePost.getContent()));
		postDAO.savePost(thePost, attachements);
	}

    @Transactional
	public Post getPost(int theId) {
		return postDAO.getPost(theId);
	}

    @Transactional
	public void deletePost(int theId) {
		Post post = postDAO.deletePost(theId);
		
        for(Attachment at : post.getAttachments()) {
        	attachmentService.deleteAttachmentFile(at.getStoredName());
        }
	}
	
	@Transactional
	public void indexing() {
		postDAO.indexing();
	}
    
    private String escapeScriptTag(String content) {
    	String result = null;
    	result = content.replaceAll("<script>", "\\<script\\>").replaceAll("</script>", "\\</script\\>");    	
    	return result;
    }

}

