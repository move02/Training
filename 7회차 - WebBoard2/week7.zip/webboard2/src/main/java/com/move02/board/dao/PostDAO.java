package com.move02.board.dao;

import java.util.List;
import java.util.Set;

import com.move02.board.model.Attachment;
import com.move02.board.model.Post;

public interface PostDAO {
	public long countPosts(String keyword, String searchBy);
	
    public List < Post > getPosts(int firstResult, int maxResult, String orderBy);

    public List < Post > getPosts(int firstResult, int maxResult, String keyword, String orderBy, String searchBy);

    public void savePost(Post thePost);
    
    public void savePost(Post thePost, Set<Attachment> attachements);

    public Post getPost(int theId);

    public Post deletePost(int theId);
    
    public void indexing();
}
