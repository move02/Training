package com.move02.board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.move02.board.model.User;
import com.move02.board.service.SessionService;
import com.move02.board.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;
	
	@Autowired
	SessionService sessionService;
	
	@GetMapping("/new")
	public String registerView(Model model, HttpSession session, HttpServletRequest request) {
		sessionService.initRsa(request);
		return "user/new";
	}
	
	@PostMapping("/create")
	public String registerUser(Model model, HttpSession session, RedirectAttributes redirectAttribute 
			, @RequestParam(required=true, name="usernameField") String username
			, @RequestParam(required=true, name="nicknameField") String nickname
			, @RequestParam(required=true, name="passwordField") String password
			, @RequestParam(required=true, name="emailField") String email) {
		
		if(userService.getUserByUsername(username) == null) {
			String decodedRsaPassword = null;
			
			try {
				decodedRsaPassword = sessionService.decryptRsa(session, password);
				System.out.println("decoded : " + decodedRsaPassword);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			User user = new User(username, nickname, decodedRsaPassword, email);
			userService.saveUser(user);
			redirectAttribute.addFlashAttribute("msgColor", "success");
			redirectAttribute.addFlashAttribute("msg", "정상적으로 가입되었습니다. 가입된 정보로 로그인하세요.");
			return "redirect:/login";
		} else {
			redirectAttribute.addFlashAttribute("msgColor", "warning");
			redirectAttribute.addFlashAttribute("msg", "이미 존재하는 아이디입니다. 중복 확인을 통해 중복을 확인해주세요.");
			return "redirect:/user/new";
		}
	}
	
	@GetMapping("/mypage")
	public String mypage(Model model, HttpSession session) {
		return "user/mypage";
	}
	
	@GetMapping("/checkuname")
	@ResponseBody
 	public boolean checkUname(@RequestParam(name="input", required=true) String inputUname) {
		boolean result = userService.checkUname(inputUname);
		return result;
	}
	
	@GetMapping("/checknname")
	@ResponseBody
 	public boolean checkNname(@RequestParam(name="input", required=true) String inputNname) {
		boolean result = userService.checkNname(inputNname);
		return result;
	}
}
