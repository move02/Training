package com.move02.board.dao;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.move02.board.model.User;

@Repository
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void saveUser(User user) {
        Session session = sessionFactory.getCurrentSession();
    	session.saveOrUpdate(user);
	}

	@Override
	public User getUser(int userId) {
		Session session = sessionFactory.getCurrentSession();
		return session.get(User.class, userId);
	}

	@Override
	public User getUserByUsername(String username) {
		Session session = sessionFactory.getCurrentSession();
        User user = null;
        
        try {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<User> cq = cb.createQuery(User.class);
            
            Root<User> root = cq.from(User.class);
            cq.select(root).where(cb.equal(root.get("username"), username));
            Query query = session.createQuery(cq);
            
        	user = (User)query.getSingleResult();
        } catch (HibernateException e) {
    		
            e.printStackTrace();
        } catch(NoResultException ex) {
        	return null;
        }
        
		return user;
	}
	
	@Override
	public User getUserByNickname(String nickname) {
		Session session = sessionFactory.getCurrentSession();
        User user = null;
        
        try {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<User> cq = cb.createQuery(User.class);
            
            Root<User> root = cq.from(User.class);
            cq.select(root).where(cb.equal(root.get("nickname"), nickname));
            Query query = session.createQuery(cq);
            
        	user = (User)query.getSingleResult();
        } catch (HibernateException e) {
    		
            e.printStackTrace();
        } catch(NoResultException ex) {
        	return null;
        }
        
		return user;
	}

}
