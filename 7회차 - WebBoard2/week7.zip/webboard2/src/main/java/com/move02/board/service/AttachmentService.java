package com.move02.board.service;

import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Attachment;

public interface AttachmentService {
	public Attachment getAttachment(int attachId);
	public void deleteAttachment(int attachId);
	public void deleteAttachmentFile(String storedName);
	public boolean validateFiles(MultipartFile[] files);
}
