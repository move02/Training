package com.move02.board.dao;

import java.util.List;

import com.move02.board.model.Comment;

public interface CommentDAO {
	public long countComments(int postId);
	
    public List < Comment > getComments(int postId);

    public void saveComment(Comment theComment);

    public Comment getComment(int theId);

    public void deleteComment(int theId);
}
