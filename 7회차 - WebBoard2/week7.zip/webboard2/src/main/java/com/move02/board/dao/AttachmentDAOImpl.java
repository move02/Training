package com.move02.board.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Attachment;

@Repository
public class AttachmentDAOImpl implements AttachmentDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public Attachment getAttachment(int attachId) {
        Session currentSession = sessionFactory.getCurrentSession();
        Attachment attachment = currentSession.get(Attachment.class, attachId);
        
        return attachment;
	}

	@Override
	public Attachment deleteAttachment(int attachId) {
        Session session = sessionFactory.getCurrentSession();
        Attachment attachment = session.byId(Attachment.class).load(attachId);
        
        session.delete(attachment);
        return attachment;
	}

}
