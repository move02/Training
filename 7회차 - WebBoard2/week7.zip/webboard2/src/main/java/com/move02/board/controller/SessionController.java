package com.move02.board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.move02.board.model.User;
import com.move02.board.service.SessionService;
import com.move02.board.service.UserService;

@Controller
@RequestMapping("")
public class SessionController {	
	@Autowired
	UserService userService;
	
	@Autowired
	SessionService sessionService;
	
	@GetMapping("/")
	public String redToLogin(Model model, HttpServletRequest request) {
		return "redirect:/login";
	}
	
	@GetMapping("/login")
	public String loginView(Model model, HttpServletRequest request) {
		sessionService.initRsa(request);
		return "/signin";
	}
	
	@PostMapping("/session/create")
	public String createSession(Model model, HttpSession session, RedirectAttributes redirectAttribute
			, @RequestParam(required=true, name="usernameField") String username
			, @RequestParam(required=true, name="passwordField") String password) {
		
		User user = userService.getUserByUsername(username);
		if(user != null) {
			String decodedRsaPassword = null;
			
			try {
				decodedRsaPassword = sessionService.decryptRsa(session, password);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			boolean matches = userService.comparePassword(decodedRsaPassword, user.getPassword());
			if(matches) {
				userService.userLogin(user, session);
				redirectAttribute.addFlashAttribute("msgColor", "success");
				redirectAttribute.addFlashAttribute("msg", "안녕하세요 " + user.getNickname() + " 님.");
				return "redirect:/post/";
			}
		}

		redirectAttribute.addFlashAttribute("msgColor", "danger");
		redirectAttribute.addFlashAttribute("msg", "로그인 실패. 아이디와 비밀번호를 확인해주세요.");
		return "redirect:/login";
	}
	
	@GetMapping("/session/delete")
	public String logout(Model model, HttpSession session, RedirectAttributes redirectAttributes) {
		
		if(session.getAttribute("username") != null) {
			session.invalidate();
			redirectAttributes.addFlashAttribute("msg", "로그아웃 되었습니다.");
		} else {
			redirectAttributes.addFlashAttribute("msg", "로그인 정보가 없습니다.");
		}
		return "redirect:/login";
	}
}
