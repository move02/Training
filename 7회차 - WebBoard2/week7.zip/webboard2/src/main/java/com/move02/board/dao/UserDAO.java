package com.move02.board.dao;

import com.move02.board.model.User;

public interface UserDAO {
	public void saveUser(User user);
	public User getUser(int userId);
	public User getUserByUsername(String username);
	public User getUserByNickname(String nickname);
}
