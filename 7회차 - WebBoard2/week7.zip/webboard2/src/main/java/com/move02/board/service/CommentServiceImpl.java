package com.move02.board.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.move02.board.dao.CommentDAO;
import com.move02.board.model.Comment;

@Service
public class CommentServiceImpl implements CommentService {
	@Autowired
	CommentDAO commentDAO;

	@Transactional
	public long countComments(int postId) {
		return commentDAO.countComments(postId);
	}

	@Transactional
	public List<Comment> getComments(int postId) {
		return commentDAO.getComments(postId);
	}

	@Transactional
	public void saveComment(Comment theComment) {
		commentDAO.saveComment(theComment);
	}

	@Transactional
	public Comment getComment(int theId) {
		return commentDAO.getComment(theId);
	}

	@Transactional
	public void deleteComment(int theId) {
		commentDAO.deleteComment(theId);
	}

	@Override
	public JsonObject toJsonObject(Comment comment) {
		JsonObject commentJson = new JsonObject();
		commentJson.addProperty("commentor_nickname", comment.getUser().getNickname());
		commentJson.addProperty("commentor_id", comment.getUser().getId());
		commentJson.addProperty("createdAt", comment.getCreatedAt().toString());
		commentJson.addProperty("content", comment.getContent());
		commentJson.addProperty("id", comment.getId());
		
		return commentJson;
	}

}
