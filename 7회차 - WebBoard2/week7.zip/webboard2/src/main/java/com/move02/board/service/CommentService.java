package com.move02.board.service;

import java.util.List;

import com.google.gson.JsonObject;
import com.move02.board.model.Comment;

public interface CommentService {
	public long countComments(int postId);

    public List < Comment > getComments(int postId);

    public void saveComment(Comment theComment);

    public Comment getComment(int theId);

    public void deleteComment(int theId);
    
    public JsonObject toJsonObject(Comment comment);
}

