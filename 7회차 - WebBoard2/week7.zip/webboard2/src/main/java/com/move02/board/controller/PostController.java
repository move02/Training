package com.move02.board.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.move02.board.model.Comment;
import com.move02.board.model.Post;
import com.move02.board.model.User;
import com.move02.board.service.AttachmentService;
import com.move02.board.service.CommentService;
import com.move02.board.service.PostService;
import com.move02.board.service.UserService;
import com.move02.board.utils.PageUtils;

@Controller
@RequestMapping("/post")
public class PostController {

	@Autowired
	private PostService postService;
	@Autowired
	private UserService userService;
	@Autowired
	private AttachmentService attachService;
	@Autowired
	private CommentService commentService;
	
	@Autowired
	private HttpServletRequest request;
	
	private User currentUser;

//	@PostConstruct
//	public void initIndexing(){
//		postService.indexing();
//	}
	
	@GetMapping("/")
	public String getPostList(Model theModel, RedirectAttributes redirectAttributes,
			@RequestParam(required = false, defaultValue = "1") int page,
			@RequestParam(required = false, defaultValue = "1") int range,
			@RequestParam(required = false) String keyword,
			@RequestParam(required = false, defaultValue="10") Integer listSize,
			// order by
			// ca => created at(등록일)
			// ua => updated at(수정일)
			@RequestParam(required = false, defaultValue = "ca") String orderBy,
			@RequestParam(required = false, defaultValue = "title") String searchBy,
			HttpServletResponse response) {
		
		currentUser = getCurrentUser(request);
		
		long count = postService.countPosts(keyword, searchBy);
		PageUtils pagination = new PageUtils();

		pagination.setListSize(listSize);
		pagination.pageInfo(page, range, count, keyword);
		
		int startVal = (pagination.getListSize() * (page - 1));
		long numbering = count - startVal;
		
		
		List<Post> thePosts = null;
		if(keyword == null) {
			thePosts = postService.getPosts(startVal, pagination.getListSize(), orderBy);
		} else {
			thePosts = postService.getPosts(startVal, pagination.getListSize(), keyword, orderBy, searchBy);
		}
		
		Cookie pageCookie = null;
		Cookie rangeCookie = null;
		Cookie keywordCookie = null;
		Cookie orderByCookie = null;
		Cookie searchByCookie = null;
		Cookie listSizeCookie = null;
		
		pageCookie = new Cookie("page", Integer.toString(page));
		pageCookie.setMaxAge(10*60*60);
		rangeCookie = new Cookie("range", Integer.toString(range));
		rangeCookie.setMaxAge(10*60*60);
		keywordCookie = new Cookie("keyword", keyword);
		keywordCookie.setMaxAge(10*60*60);
		orderByCookie = new Cookie("orderBy", orderBy);
		orderByCookie.setMaxAge(10*60*60);
		searchByCookie = new Cookie("searchBy", searchBy);
		searchByCookie.setMaxAge(10*60*60);
		listSizeCookie = new Cookie("listSize", Integer.toString(listSize));
		listSizeCookie.setMaxAge(10*60*60);
		
		response.addCookie(pageCookie);
		response.addCookie(rangeCookie);
		response.addCookie(keywordCookie);
		response.addCookie(orderByCookie);
		response.addCookie(searchByCookie);
		response.addCookie(listSizeCookie);

		theModel.addAttribute("count", count);
		theModel.addAttribute("currentUser", currentUser);
		theModel.addAttribute("numbering", numbering);
		theModel.addAttribute("orderBy", orderBy);
		theModel.addAttribute("searchBy", searchBy);
		theModel.addAttribute("pagination", pagination);
		theModel.addAttribute("posts", thePosts);
		
		return "post/index";
	}

	@GetMapping("/{postId}")
	public String showPost(Model theModel, @PathVariable("postId") int theId, RedirectAttributes redirectAttributes) {
		Post post = postService.getPost(theId);
		currentUser = getCurrentUser(request);
		List<Comment> comments = commentService.getComments(theId);
		
		theModel = retrieveCookie(theModel);
		
		String resourcePath = getBaseURL(request)+"/resources/uploads/";
		
		theModel.addAttribute("currentUser", currentUser);
		theModel.addAttribute("resourcePath", resourcePath);
		theModel.addAttribute("post", post);
		theModel.addAttribute("comments", comments);
		return "post/show";
	}

	@GetMapping("/new")
	public String showFormForAdd(Model theModel, RedirectAttributes redirectAttributes) {
		Post thePost = new Post();
		theModel = retrieveCookie(theModel);
		
		theModel.addAttribute("author", currentUser);
		theModel.addAttribute("post", thePost);
		return "post/post-form";
	}

	@PostMapping("/save")
	public String savePost(Model model, @Valid @ModelAttribute("post") Post thePost, RedirectAttributes redirectAttributes, BindingResult result, 
			@RequestParam("multiFiles") MultipartFile[] files,
			@RequestParam(name="to_deleted", required=false) int[] toDeletedFiles) {		
		Hibernate.initialize(thePost.getAttachments());
		
		String authorName = (String) request.getSession().getAttribute("username");
		User author = userService.getUserByUsername(authorName);
		currentUser = getCurrentUser(request);
		
		if(thePost.getId() != null) {
			if(!userService.hasAuth(author, currentUser)) {
				redirectAttributes.addFlashAttribute("msg", "글 수정 권한이 없습니다.");
				redirectAttributes.addFlashAttribute("msgColor", "warning");
				return "redirect:/post/";
			}
		}
		
//		if(!attachService.validateFiles(files)) {
//			model.addAttribute("post", thePost);
//			redirectAttributes.addFlashAttribute("msg", "허용되지 않은 파일 형식입니다. (가능 : word, ppt, excel, pdf, image)");
//			return "redirect:/post/";
//		}
		
		thePost.setUser(author);
		
		int totalSize = 0;
		
		if(thePost.getAttachments() != null) {
			if(toDeletedFiles != null)
				totalSize = files.length + thePost.getAttachments().size() - toDeletedFiles.length;
			else
				totalSize = files.length + thePost.getAttachments().size();
		}
		else {
			if(toDeletedFiles != null)
				totalSize = files.length - toDeletedFiles.length;
			else
				totalSize = files.length;
		}
		
		if(toDeletedFiles != null) {
			for(int attachId : toDeletedFiles) {
				attachService.deleteAttachment(attachId);
			}
		}
		
		thePost.setUpdatedAt(LocalDateTime.now());
		
		if (totalSize > 0)
			postService.savePost(thePost, files);
		else
			postService.savePost(thePost);
		
		redirectAttributes.addFlashAttribute("msgColor", "success");
		redirectAttributes.addFlashAttribute("msg", "성공적으로 작성되었습니다.");
		return "redirect:/post/" + thePost.getId();
	}


	@GetMapping("/update/{postId}")
	public String showFormForUpdate(@PathVariable("postId") int theId, Model theModel, RedirectAttributes redirectAttributes) {
		Post thePost = postService.getPost(theId);
		Hibernate.initialize(thePost.getAttachments());
		Hibernate.initialize(thePost.getUser());
		
		User author = thePost.getUser();
		currentUser = getCurrentUser(request);
		
		System.out.println("Author : " + author.getUsername() + " user : " + currentUser.getUsername());
		
		if(!userService.hasAuth(author, currentUser)) {
			redirectAttributes.addFlashAttribute("msg", "글 수정 권한이 없습니다.");
			redirectAttributes.addFlashAttribute("msgColor", "warning");
			return "redirect:/post/";
		}

		theModel = retrieveCookie(theModel);
		theModel.addAttribute("author", currentUser);
		theModel.addAttribute("post", thePost);
		theModel.addAttribute("isupdate", true);
		theModel.addAttribute("attachements", thePost.getAttachments());
		return "post/post-form";
	}

//	@DeleteMapping("/delete/{postId}")
	@GetMapping("/delete/{postId}")
	public String deletePost(@PathVariable("postId") int theId, RedirectAttributes redirectAttributes) {
		Post post = postService.getPost(theId);
		Hibernate.initialize(post.getUser());
		
		currentUser = getCurrentUser(request);
		
		User author = post.getUser();
		if(!userService.hasAuth(author, currentUser)) {
			redirectAttributes.addFlashAttribute("msg", "글 삭제 권한이 없습니다.");
			redirectAttributes.addFlashAttribute("msgColor", "warning");
			return "redirect:/post/";
		} else {
			postService.deletePost(theId);		
			return "redirect:/post/";
		}
	}
	
	@GetMapping("/deleteall")
	public String deleteAllPosts(@RequestParam("delete-post") int[] ids, RedirectAttributes redirectAttributes) {
		currentUser = getCurrentUser(request);
		
		if(currentUser.isAdmin()) {
			for(int id : ids) {
				postService.deletePost(id);
			}
			redirectAttributes.addFlashAttribute("msg", "성공적으로 삭제되었습니다.");
			redirectAttributes.addFlashAttribute("msgColor", "success");
		} else {
			redirectAttributes.addFlashAttribute("msg", "권한이 없습니다.");
			redirectAttributes.addFlashAttribute("msgColor", "warning");
		}
		return "redirect:/post/";
	}
	
	private Model retrieveCookie(Model theModel) {
		int page = 1, range = 1;
		String keyword = null;
		String orderBy = null;
		String searchBy = null;
		Integer listSize = null;
		
		for(Cookie cookie : request.getCookies()) {
			if(cookie.getName().equals("page")) {
				page = Integer.parseInt(cookie.getValue());
			}
			else if(cookie.getName().equals("range")) {
				range = Integer.parseInt(cookie.getValue());
			}
			else if(cookie.getName().equals("keyword")) {
				keyword = cookie.getValue();
			}
			else if(cookie.getName().equals("orderBy")) {
				orderBy = cookie.getValue();
			}
			else if(cookie.getName().equals("searchBy")) {
				searchBy = cookie.getValue();
			}
			else if(cookie.getName().equals("listSize")) {
				listSize = Integer.parseInt(cookie.getValue());
			}
		}
		
		theModel.addAttribute("page", page);
		theModel.addAttribute("range", range);
		theModel.addAttribute("keyword", keyword);
		theModel.addAttribute("orderBy", orderBy);
		theModel.addAttribute("searchBy", searchBy);
		theModel.addAttribute("listSize", listSize);
		
		return theModel;
	}
	
    //get base URL
    private String getBaseURL(HttpServletRequest request){
        return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();
    }
    
    //get current User
    private User getCurrentUser(HttpServletRequest request) {
    	return userService.getUserByUsername((String)request.getSession().getAttribute("username"));
    }
    
}