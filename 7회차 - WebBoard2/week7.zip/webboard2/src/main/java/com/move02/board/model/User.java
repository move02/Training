package com.move02.board.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.validator.constraints.NotEmpty;

import com.move02.board.utils.EmailValidator;


@Entity
@Table(name = "t_users")
public class User implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "username", unique=true)
	@Size(max = 40, message = "{user.username.invalid}")
	@NotEmpty(message = "Please Enter user name")
	private String username;
	
	@Column(name = "nickname", unique=true)
	@Size(max = 40, message = "{user.nickname.invalid}")
	@NotEmpty(message = "Please Enter nick name")
	private String nickname;
	
	@Column(name = "password")
	@Size(max = 100, message = "{user.password.invalid}")
	@NotEmpty(message = "Please Enter password")
	private String password;

	@EmailValidator
	@Column(name = "email")
	@Size(max = 100, message = "{user.email.invalid}")
	@NotEmpty(message = "Please Enter email")
	private String email;
	
	@Column(name = "isadmin")
	private boolean isadmin;
	
	@Column(name = "created_at", nullable = false, columnDefinition = "datetime")
	@CreationTimestamp
	private LocalDateTime createdAt;

	@Column(name = "updated_at", nullable = false, columnDefinition = "datetime")
	@UpdateTimestamp
	private LocalDateTime updatedAt;
	
	@Column(name = "last_login", columnDefinition = "datetime")
	private LocalDateTime lastLogin;

    @OneToMany(mappedBy="user", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Post> posts;
    
    @OneToMany(mappedBy="user", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<Comment> comments;
    
    @OneToMany(mappedBy="user", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<LikePost> likePosts;
    
    @OneToMany(mappedBy="user", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<LikeComment> likeComments;
    
    public User() {
    	
    }

	public User(String username, String nickname, String password, String email) {
		this.username = username;
		this.nickname = nickname;
		this.password = password;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAdmin() {
		return isadmin;
	}

	public void setAdmin(boolean isadmin) {
		this.isadmin = isadmin;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public LocalDateTime getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(LocalDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public List<LikePost> getLikePosts() {
		return likePosts;
	}

	public void setLikePosts(List<LikePost> likePosts) {
		this.likePosts = likePosts;
	}

	public List<LikeComment> getLikeComments() {
		return likeComments;
	}

	public void setLikeComments(List<LikeComment> likeComments) {
		this.likeComments = likeComments;
	}
    
    

}
