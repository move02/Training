package com.move02.board.service;

import javax.servlet.http.HttpSession;

import com.move02.board.model.User;

public interface UserService {
	public User getUser(int userId);
	public User getUserByUsername(String username);
	public void saveUser(User user);
	public void deleteUser(int userId);
	public boolean comparePassword(String raw, String userPassword);
	public boolean checkLogin(HttpSession session);
	public void userLogin(User user, HttpSession session);
	public boolean checkUname(String inputUname);
	public boolean checkNname(String inputNname);
	public boolean hasAuth(User author, User currentUser);
}
