package com.move02.board.service;

public interface Likable {

}
