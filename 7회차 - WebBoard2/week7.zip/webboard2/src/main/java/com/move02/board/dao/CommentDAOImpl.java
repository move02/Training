package com.move02.board.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.move02.board.model.Comment;

@Repository
public class CommentDAOImpl implements CommentDAO {
	@Autowired
	SessionFactory sessionFactory;
	
	@Override
	public long countComments(int postId) {
		List<Comment> comments = null;
		Session session = sessionFactory.getCurrentSession();
		String sql = "from Comment as comment where comment.post.id = :postId";
		
		Query query = session.createQuery(sql);
		query.setParameter("postId", postId);
		
		comments = query.getResultList();
		if(comments == null)
			return 0;
		else
			return comments.size();
	}

	@Override
	public List<Comment> getComments(int postId) {
		List<Comment> comments = null;
		Session session = sessionFactory.getCurrentSession();

		String sql = "from Comment where post.id = :postId"
				+ " order by createdAt desc";
		
		Query query = session.createQuery(sql);
		query.setParameter("postId", (long)postId);
		
		comments = query.getResultList();
	
		return comments;
	}

	@Override
	public void saveComment(Comment theComment) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(theComment);
	}

	@Override
	public Comment getComment(int theId) {
		Session session = sessionFactory.getCurrentSession();
		Comment comment = session.get(Comment.class, theId);
		Hibernate.initialize(comment.getUser());
		return comment;
	}

	@Override
	public void deleteComment(int theId) {
		Session session = sessionFactory.getCurrentSession();
		
		Comment comment = session.get(Comment.class, theId);
		session.delete(comment);
	}

}
