package com.move02.board.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.FlashMap;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.move02.board.model.User;
import com.move02.board.service.UserService;

public class AuthInterceptor extends HandlerInterceptorAdapter{
	
	@Autowired
	UserService userService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		if(userService.checkLogin(request.getSession())) {
			User currentUser = userService.getUserByUsername((String)request.getSession().getAttribute("username"));
			request.setAttribute("currentUser", currentUser);
			return super.preHandle(request, response, handler);
		}
		else {
			String loginUrl = request.getContextPath() + "/login";
			FlashMap outputFlashMap = RequestContextUtils.getOutputFlashMap(request);
            outputFlashMap.put("msg", "로그인이 필요한 서비스입니다.");
            outputFlashMap.put("msgColor", "warning");
            RequestContextUtils.saveOutputFlashMap(loginUrl, request, response);
			response.sendRedirect(loginUrl);
			return false;
		}
	}
	
}
