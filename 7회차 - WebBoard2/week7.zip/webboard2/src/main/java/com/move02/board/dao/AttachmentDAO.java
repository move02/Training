package com.move02.board.dao;

import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Attachment;

public interface AttachmentDAO {
	public Attachment getAttachment(int attachId);
	public Attachment deleteAttachment(int attachId);
}
