package com.move02.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/error")
public class ErrorController {
	
	@GetMapping("/throwable")
	public String throwable(Model model) {
		model.addAttribute("msg", "예상치 못한 문제가 발생했어요.");
		model.addAttribute("code", "throwable");
		return "error";
	}
	
	@GetMapping("/exception")
	public String exception(Model model) {
		model.addAttribute("msg", "예상치 못한 문제가 발생했어요.");
		model.addAttribute("code", "exception");
		return "error";
	}
	
	@GetMapping("/400")
	public String error400(Model model) {
		model.addAttribute("msg", "잘못된 요청이예요.");
		model.addAttribute("code", "400");
		return "error";
	}
	
	@GetMapping("/403")
	public String error403(Model model) {
		model.addAttribute("msg", "접근이 금지되어있어요.");
		model.addAttribute("code", "403");
		return "error";
	}
	
	@GetMapping("/404")
	public String error404(Model model) {
		model.addAttribute("msg", "찾으시는 페이지가 없어요.");
		model.addAttribute("code", "404");
		return "error";
	}
	
	@GetMapping("/405")
	public String error405(Model model) {
		model.addAttribute("msg", "요청하신 방법은 허용되지 않아요.");
		model.addAttribute("code", "405");
		return "error";
	}
	
	@GetMapping("/500")
	public String error500(Model model) {
		model.addAttribute("msg", "서버 오류입니다. 관리자에게 문의주세요.");
		model.addAttribute("code", "500");
		return "error";
	}
	
	@GetMapping("/503")
	public String error503(Model model) {
		model.addAttribute("msg", "현재 일시적으로 이용할 수 없어요.");
		model.addAttribute("code", "503");
		return "error";
	}
}
