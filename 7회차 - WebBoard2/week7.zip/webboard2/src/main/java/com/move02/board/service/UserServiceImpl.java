package com.move02.board.service;

import java.time.LocalDateTime;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.move02.board.dao.UserDAO;
import com.move02.board.model.User;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDAO userDAO;
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Transactional
	public User getUser(int userId) {
		return userDAO.getUser(userId);
	}
	
	@Transactional
	public User getUserByUsername(String username) {
		return userDAO.getUserByUsername(username);
	}

	@Transactional
	public void saveUser(User user) {
		user.setPassword(encPassword(user.getPassword()));
		userDAO.saveUser(user);
	}

	@Transactional
	public void deleteUser(int userId) {
		User user = userDAO.getUser(userId);
		// set user info to deleted user
		userDAO.saveUser(user);
	}
	
	@Transactional
	public void userLogin(User user, HttpSession session) {
		user.setLastLogin(LocalDateTime.now());
		userDAO.saveUser(user);
		
		session.setAttribute("username", user.getUsername());
		session.setAttribute("isadmin", user.isAdmin());
	}

	@Transactional
	public boolean checkUname(String inputUname) {
		User u = userDAO.getUserByUsername(inputUname);
		if(u == null)
			return false;
		else
			return true;
	}

	@Transactional
	public boolean checkNname(String inputNname) {
		User u = userDAO.getUserByNickname(inputNname);
		if(u == null)
			return false;
		else
			return true;
	}

	//
	// Non transactional Methods
	//
	
	public boolean comparePassword(String raw, String userPassword) {
		return passwordEncoder.matches(raw, userPassword);
	}
	
	private String encPassword(String raw) {
		String encoded = passwordEncoder.encode(raw);
		return encoded;
	}
	
	public boolean checkLogin(HttpSession session) {
		if(session.getAttribute("username") != null)
			return true;
		else
			return false;
	}
	
	public boolean hasAuth(User author, User currentUser) {
		if(author.getUsername().equals(currentUser.getUsername()) || currentUser.isAdmin()) {
			return true;
		} else {
			return false;
		}
	}
}
