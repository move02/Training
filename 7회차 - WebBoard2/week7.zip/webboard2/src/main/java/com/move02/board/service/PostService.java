package com.move02.board.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.move02.board.model.Post;

public interface PostService {
	public long countPosts(String keyword, String searchBy);

    public List < Post > getPosts(int firstResult, int maxResult, String orderBy);
    
    public List < Post > getPosts(int firstResult, int maxResult, String keyword, String orderBy, String searchBy);

    public void savePost(Post thePost);
    
    public void savePost(Post thePost, MultipartFile[] files);

    public Post getPost(int theId);

    public void deletePost(int theId);
    
    public void indexing();
}