package com.move02.board.controller;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.JsonObject;
import com.move02.board.model.Comment;
import com.move02.board.model.Post;
import com.move02.board.model.User;
import com.move02.board.service.CommentService;
import com.move02.board.service.PostService;
import com.move02.board.service.UserService;

@Controller
@RequestMapping("/comment")
public class CommentController {
	
	@Autowired
	CommentService commentService;
	@Autowired
	UserService userService;
	@Autowired
	PostService postService;
	
	private User currentUser;
	
	@PostMapping("/create")
	@ResponseBody
	public JsonObject createComment(HttpServletRequest request, @RequestParam(required=true) String content,
			@RequestParam(required=true) Integer postId,
			@RequestParam(required=false) Integer parentId) {
		
		Comment comment = new Comment();
		comment.setContent(content);
		
		currentUser = getCurrentUser(request);
		comment.setUser(currentUser);
		
		Post post = postService.getPost(postId);
		comment.setPost(post);
		
		commentService.saveComment(comment);
		
		return commentService.toJsonObject(comment);
	}
	
	@GetMapping("/delete")
	@ResponseBody
	public String deleteComment(HttpServletRequest request, @RequestParam(required=false) Integer commentId,
			RedirectAttributes redirectAttributes) {
		currentUser = getCurrentUser(request);
		
		Comment comment = commentService.getComment(commentId);
		Hibernate.initialize(comment.getUser());
		if(comment.getUser().getId() == currentUser.getId()) {
			commentService.deleteComment(commentId);
			return "ok";
		} else {
			return "false";
		}
	}
    
    //get current User
    private User getCurrentUser(HttpServletRequest request) {
    	return userService.getUserByUsername((String)request.getSession().getAttribute("username"));
    }
	
}
